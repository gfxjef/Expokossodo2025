-- Datos de tabla expokossodo_asistencias_por_sala
-- Fecha: 2025-09-02 09:01:28.299248
-- Registros: 9

INSERT INTO expokossodo_asistencias_por_sala_backup (`id`, `registro_id`, `evento_id`, `qr_escaneado`, `fecha_ingreso`, `asesor_verificador`, `ip_verificacion`, `notas`) VALUES
(21, 932, 22, 'ric51990360028gersim1756317144', '2025-09-01 16:52:49', 'Staff-Sala', '10.214.104.89', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(22, 1074, 22, 'may51900512375metmet1756662312', '2025-09-01 16:54:17', 'Staff-Sala', '10.214.238.93', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(23, 1110, 8, 'jor51968255746dirims1756749904', '2025-09-01 16:56:09', 'Staff-Sala', '10.214.3.27', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(24, 1110, 4, 'jor51968255746dirims1756749904', '2025-09-01 17:01:12', 'Staff-Sala', '10.214.238.93', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(25, 1110, 1, 'jor51968255746dirims1756749904', '2025-09-01 17:22:52', 'Staff-Sala', '10.214.74.253', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(26, 1110, 28, 'jor51968255746dirims1756749904', '2025-09-01 17:38:38', 'Staff-Sala', '10.214.104.89', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(27, 905, 2, 'alf51995087640ingcon1756252512', '2025-09-02 00:13:06', 'Staff-Sala', '10.214.104.89', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(28, 1068, 44, 'hid51966003824supite1756649216', '2025-09-02 03:13:59', 'Staff-Sala', '127.0.0.1', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado'),
(29, 214, 44, 'ana51930852410tecuna1756243237', '2025-09-02 03:17:31', 'Staff-Sala', '127.0.0.1', 'Agregado y registrado por Staff-Sala - Sobrecupo autorizado');

