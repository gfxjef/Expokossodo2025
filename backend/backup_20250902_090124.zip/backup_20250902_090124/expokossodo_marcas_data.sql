-- Datos de tabla expokossodo_marcas
-- Fecha: 2025-09-02 09:01:29.124247
-- Registros: 13

INSERT INTO expokossodo_marcas_backup (`id`, `marca`, `expositor`, `logo`, `created_at`, `updated_at`) VALUES
(1, 'CAMAG', 'Ing. Eliezer Ceniviva', 'https://i.ibb.co/67rBmW1c/camag-blanco.webp', '2025-07-11 18:11:14', '2025-07-11 18:25:11'),
(2, 'EVIDENT', 'Mario Esteban Muñoz', 'https://i.ibb.co/9MgkP7L/evident-blanco.webp', '2025-07-11 18:11:14', '2025-07-11 18:25:20'),
(3, 'ESCO', NULL, 'https://i.ibb.co/0RpVnmPF/esco-blanco.webp', '2025-07-11 18:11:14', '2025-07-11 18:25:28'),
(4, 'VACUUBRAND', 'Dr. Roberto Friztler', 'https://i.ibb.co/Y4tvtKyb/vacubrand-blanco.webp', '2025-07-11 18:11:14', '2025-07-11 18:25:41'),
(5, 'SARTORIUS', 'Lic. Mónica Klarreich', 'https://i.ibb.co/GvJhvb3w/sartorius-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:25:47'),
(6, 'LAUDA', 'Andre Sautchuk', 'https://i.ibb.co/M5f6dwxS/lauda-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:25:53'),
(7, 'BINDER', 'PhD. Fernando Vargas', 'https://i.ibb.co/sv2g4YPT/binder-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:26:00'),
(8, 'VELP', 'Pablo Scarpin', 'https://i.ibb.co/QvT055f5/velp-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:26:06'),
(9, 'ANALITYCCHEM', NULL, 'https://i.ibb.co/My7PfY0f/chem-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:26:24'),
(10, 'AMS', NULL, 'https://i.ibb.co/LD44PGkG/ams-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:26:33'),
(11, 'KOSSODO', 'Qco. James Rojas Sanchez', 'https://i.ibb.co/M5f6dwxS/lauda-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:27:12'),
(12, 'KOSSOMET', 'Jhonny Quispe', 'https://i.ibb.co/0RpVnmPF/esco-blanco.webp', '2025-07-11 18:11:15', '2025-07-11 18:27:01'),
(81, 'CHEM', NULL, 'https://i.ibb.co/LXZ02Zb3/chem-color.webp', '2025-07-11 18:29:22', '2025-07-11 18:29:22');

