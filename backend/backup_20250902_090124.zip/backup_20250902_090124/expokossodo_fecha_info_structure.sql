-- Estructura de tabla expokossodo_fecha_info
-- Fecha: 2025-09-02 09:01:28.768246
-- Registros: 7

DROP TABLE IF EXISTS expokossodo_fecha_info_backup;
CREATE TABLE `expokossodo_fecha_info_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `rubro` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo_dia` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `ponentes_destacados` json DEFAULT NULL,
  `marcas_patrocinadoras` json DEFAULT NULL,
  `paises_participantes` json DEFAULT NULL,
  `imagen_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fecha` (`fecha`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_activo` (`activo`),
  KEY `idx_rubro` (`rubro`)
) ENGINE=InnoDB AUTO_INCREMENT=2127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

