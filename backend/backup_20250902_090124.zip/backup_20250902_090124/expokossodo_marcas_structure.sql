-- Estructura de tabla expokossodo_marcas
-- Fecha: 2025-09-02 09:01:29.122245
-- Registros: 13

DROP TABLE IF EXISTS expokossodo_marcas_backup;
CREATE TABLE `expokossodo_marcas_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `marca` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expositor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marca` (`marca`),
  KEY `idx_marca` (`marca`)
) ENGINE=InnoDB AUTO_INCREMENT=5005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

