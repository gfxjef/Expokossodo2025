-- Datos de tabla expokossodo_eventos
-- Fecha: 2025-09-02 09:01:27.576254
-- Registros: 48

INSERT INTO expokossodo_eventos_backup (`id`, `fecha`, `hora`, `sala`, `titulo_charla`, `slug`, `expositor`, `pais`, `descripcion`, `imagen_url`, `post`, `marca_id`, `slots_disponibles`, `slots_ocupados`, `disponible`, `created_at`, `rubro`) VALUES
(1, '2025-09-02', '15:00-15:45', 'sala1', 'Vacío bajo control: eficiencia y calidad para tu laboratorio de hoy', 'vacio-que-cumple-tecnologia-inteligente-para-auditar-sin-estres', 'Dr. Roberto Friztler', 'Alemania', 'Podrás descubrir cómo el sistema de vacío inteligente de VACCUBRAND simplifica tus auditorías de humedad y pérdida de masa, combinando precisión y conectividad para resultados confiables sin estrés. Obtendrás una visión clara de los principios del calentamiento por infrarrojo y la medición gravimétrica optimizada por tecnología de vacío controlado. Encontraremos juntos las mejores prácticas para operar y mantener el equipo, integrándolo efectivamente con tus procesos de laboratorio. Observaremos en detalle cómo interpretar los datos generados y convertirlos en informes útiles para tu gestión de calidad.

## Contenido y dinámicas prácticas  
- **Fundamentos del “SmartVac”**: Exploración de la tecnología de vacío controlado y su impacto en el calentamiento por infrarrojo.  
- **Operación paso a paso**: Configuración de parámetros, calibración automática y uso de herramientas digitales para el monitoreo.  
- **Pruebas con muestras diversas**: Ejercicios prácticos con alimentos, polímeros y minerales para medir deshidratación y generación de cenizas.  
- **Análisis e interpretación**: Observación de curvas de pérdida de peso y extracción de conclusiones sobre propiedades físico-químicas.

## Beneficios clave  
- **Eficiencia operativa**: Reducción de tiempos de ciclo y errores manuales.  
- **Conectividad avanzada**: Integración directa con plataformas de gestión y trazabilidad.  
- **Resultados consistentes**: Precisión reproducible bajo estándares internacionales.  
', 'https://i.postimg.cc/76ZxtKsW-/enhanced-image-5.png', 'https://i.ibb.co/mCXCkL70/Mesa-de-trabajo-102.png', 4, 60, 60, 1, '2025-06-05 13:12:07', '["Alimentos", "Minería", "Farmacéutica", "Pesquera"]'),
(2, '2025-09-02', '15:00-15:45', 'sala2', 'Medicion del DBO y su impacto en el medio ambiente', 'medicion-del-dbo-y-su-impacto-en-el-medio-ambiente', 'Pablo Scarpin - Business Development Manager', 'Argentina', '
En este taller de **Velp** aprenderás los fundamentos de la medición de la Demanda Bioquímica de Oxígeno (DBO), un parámetro clave para evaluar la calidad del agua y su capacidad de sostener vida acuática. A través de teoría y práctica, conocerás los principios detrás del método DBO5, las normativas vigentes y cómo interpretar los resultados para tomar decisiones ambientales responsables.

## 
- **Salud de los ecosistemas**: Comprender la DBO permite detectar contaminación orgánica y prevenir la proliferación de algas y zonas muertas.  
- **Cumplimiento normativo**: Asegura que tus muestreos cumplan con estándares locales e internacionales (EPA, ISO 5815).  
- **Gestión eficiente de recursos**: Optimiza tiempos y reactivos al emplear técnicas modernas y equipos Velp de bajo consumo.  
- **Responsabilidad social**: Contribuye a la preservación de fuentes de agua potable y vida acuática, mejorando la imagen y compromiso ambiental de tu organización.

## 
1. **Preparación de muestras**  
   - Selección de puntos de muestreo y toma de muestra representativa.  
   - Conservación y transporte según normativas.  
2. **Ejecutando la prueba DBO5**  
   - Uso de digestoress y biorreactores Velp para oxidación controlada.  
   - Registro de oxígeno disuelto inicial y final con oxímetros precisos.  
   - Cálculo de la DBO y análisis de desviaciones.  
3. **Interpretación de datos y acción**  
   - Comparativa con valores guía y límites legales.  
   - Diseño de planes de tratamiento de aguas residuales (aireación, biofiltros).  
   - Generación de informes y comunicación de hallazgos.


', 'https://i.ibb.co/xx1Gtfn/velp-2.webp', 'https://i.ibb.co/3ykqMCdG/Mesa-de-trabajo-98-copia.png', 8, 65, 66, 1, '2025-06-05 13:12:07', '["Química & Petrolera", "Educación", "Aguas y bebidas", "Minería", "Pesquera"]'),
(3, '2025-09-02', '15:00-15:45', 'sala3', 'Claves de la fase estacionaria en cromatografía de gases para análisis en alimentos', 'claves-de-la-fase-estacionaria-en-cromatografia-de-gases-para-analisis-en-alimentos', 'Qco. James Rojas Sanchez - Asesor Técnico', 'Perú', 'Podrás explorar el rol fundamental de la fase estacionaria en la cromatografía de gases, especialmente en el contexto del análisis de compuestos volátiles en alimentos. Encontraremos cómo la selección adecuada de columnas capilares y sus características físico-químicas pueden marcar la diferencia entre una separación eficiente y resultados confusos. Esta sesión está diseñada para ayudarte a comprender a fondo los parámetros que definen el rendimiento cromatográfico, desde la polaridad hasta el grosor de la película.

## Contenido y dinámicas prácticas  
- **Tipos de fases estacionarias**: Características de columnas polares, apolares e intermedias, y su relación con diferentes matrices alimentarias.  
- **Selección de columnas**: Criterios clave para elegir columnas según el tipo de muestra y los analitos de interés.  
- **Optimización del método cromatográfico**: Cómo ajustar la temperatura, flujo y longitud de columna para mejorar la resolución.  
- **Diagnóstico y cuidado de columnas**: Identificación de problemas comunes y buenas prácticas para prolongar su vida útil.  

## Lo que obtendrás  
- Comprenderás cómo la fase estacionaria impacta directamente en la resolución, sensibilidad y tiempo de análisis.  
- Observarás ejemplos prácticos de separación de compuestos en alimentos como aceites, especias y bebidas.  
- Aprenderás a seleccionar la columna ideal para tus necesidades analíticas y a interpretar los resultados con mayor precisión.  
', 'https://i.ibb.co/vCnP97Vf/col-hplc.webp', 'https://i.ibb.co/LD41WJjM/Mesa-de-trabajo-73-2.png', NULL, 60, 60, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(4, '2025-09-02', '15:00-15:45', 'sala4', 'Calibración de medidores volumétricos (Lab Gdes. Volúmenes)', 'calibracion-de-medidores-volumetricos-lab-gdes-volumenes', 'Lic. Luis E. Urbano', 'Perú', '
En esta charla se podrá conocer la forma de calibración de medidores volumétricos metálicos de diferentes clases y por diferentes métodos, tales como el método gravimétrico y el método volumétrico.  
Conoceremos los fundamentos técnicos de calibración de ambos métodos usando patrones trazables al SI (Sistema Internacional de Unidades).  
Podrás conocer de forma teórica y práctica la calibración de medidores de grandes volúmenes, usados en diferentes industrias.

### Contenido y dinámicas prácticas
- **Principios de calibración**: Revisión de fundamentos técnicos y normativos tales como la ISO, Guías y Norma Metrológica Peruana.  
- **Técnicas de calibración directa e indirecta**: Calibración por método volumétrico y calibración por método gravimétrico. Ventajas del uso de cada método.  
- **Instrumentos y condiciones críticas**: Medidores volumétricos patrones, instrumentos para medir la temperatura del medio ambiente y del líquido, y los requisitos que se necesitan para realizar la calibración de ambos métodos.  
- **Ejercicios prácticos**: Ensayo práctico de cómo se calibra un serafín de 5 galones por el método volumétrico (con enfoque didáctico).  

### Lo que obtendrás
- Podrás aplicar procedimientos de calibración adecuados según el tipo de medidor y rango de volumen.  
- Aprenderás a identificar fuentes de error y cómo minimizarlas en tus mediciones diarias.  
- Observaremos casos reales y soluciones aplicadas para mantener la precisión de equipos en laboratorios, industria o investigación.
', 'https://i.ibb.co/VcspRpwY/kssdd.webp', 'https://i.ibb.co/mjdGczr/Mesa-de-trabajo-82.png', 12, 60, 68, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(5, '2025-09-02', '16:00-16:45', 'sala1', 'Buenas Prácticas de Pipeteo para Resultados Confiables y Reproducibles', 'buenas-practicas-de-pipeteo-para-resultados-confiables-y-reproducibles', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Podrás identificar y corregir los errores más comunes que afectan la precisión en uno de los procesos más rutinarios del laboratorio: el pipeteo. A través de esta sesión dinámica, encontraremos las claves para lograr mediciones consistentes y exactas, incluso en procedimientos altamente sensibles. Observaremos cómo pequeños detalles en la técnica, el mantenimiento del equipo o la ergonomía del trabajo pueden marcar una gran diferencia en la calidad de tus resultados.

## Contenido y dinámicas prácticas  
- **Técnica de pipeteo paso a paso**: Posición del cuerpo, ángulo de inmersión, ritmo y consistencia del aspirado/dispensado.  
- **Factores que afectan la precisión**: Temperatura, viscosidad del líquido, tipo de punta y calibración del instrumento.  
- **Errores comunes y cómo evitarlos**: Identificación de prácticas incorrectas y estrategias correctivas.  
- **Ejercicios prácticos**: Evaluación de la variabilidad intra e interusuario mediante pruebas de repetibilidad.  

## Lo que obtendrás  
- Obtendrás herramientas concretas para mejorar tus resultados desde el primer uso.  
- Aprenderás a reconocer cuándo una micropipeta requiere mantenimiento o recalibración.  
- Podrás aplicar buenas prácticas de forma estandarizada en tu equipo de trabajo, elevando la calidad de tus análisis.  
', 'https://i.ibb.co/pr41cCH9/sart-32.webp', 'https://www.kossomet.com/AppUp/expokossodo/adds/526202879_599385052999898_3498470765215770220_n.jpeg', 5, 70, 76, 1, '2025-06-05 13:12:07', '["Alimentos", "Salud", "Educación", "Aguas y bebidas", "Farmacéutica"]'),
(6, '2025-09-02', '16:00-16:45', 'sala2', 'Sistemas de control de temperatura precisos y de bajo impacto ambiental ', 'sistemas-de-control-de-temperatura-precisos-y-de-bajo-impacto-ambiental', 'Andre Sautchuk - Managing Director', 'Brasil', 'Encontraremos en esta charla un enfoque innovador para lograr un equilibrio entre precisión técnica y sostenibilidad en los laboratorios de alimentos. Podrás descubrir cómo los sistemas de control de temperatura modernos —como baños termostatados, refrigeradores y circuladores de última generación— están diseñados para mantener condiciones exactas sin comprometer el medio ambiente. Observaremos cómo adoptar tecnologías eficientes permite reducir consumo energético, emisiones y costos operativos, sin sacrificar rendimiento.

## Contenido y dinámicas prácticas  
- **Principios de control térmico eficiente**: Cómo funcionan los sistemas modernos de calefacción y enfriamiento en procesos analíticos.  
- **Selección de equipos sostenibles**: Criterios técnicos y ambientales para elegir sistemas de recirculación, enfriadores y termostatos.  
- **Impacto ambiental del laboratorio**: Evaluación del consumo energético y estrategias para minimizar la huella de carbono.  
- **Aplicaciones en la industria alimentaria**: Casos de uso en análisis de estabilidad, viscosidad, conservación y procesamiento.

## Lo que obtendrás  
- Podrás identificar qué soluciones térmicas se adaptan mejor a tus procesos, sin afectar la sostenibilidad.  
- Aprenderás a interpretar especificaciones técnicas que favorecen un menor consumo y mayor eficiencia.  
- Observarás cómo un enfoque ecológico puede integrarse fácilmente en el laboratorio, promoviendo una cultura de mejora continua y responsabilidad ambiental.  ', 'https://i.ibb.co/gbYDK1Wm/laud-2.webp', 'https://i.ibb.co/FqJjNdk0/Mesa-de-trabajo-98.png', 6, 60, 39, 1, '2025-06-05 13:12:07', '["Alimentos", "Pesquera"]'),
(7, '2025-09-02', '16:00-16:45', 'sala3', 'Temperatura Bajo Control: Seguridad y Calidad en Cada Grado', 'temperatura-bajo-control-seguridad-y-calidad-en-cada-grado', 'Daniel Torres', 'Venezuela', 'Descubre cómo una gestión adecuada de la temperatura es esencial para la integridad de productos sensibles y la sostenibilidad de procesos. Esta capacitación mostrará la importancia de monitorear y controlar condiciones térmicas en medios isotermos, almacenes y equipos de conservación. Se abordarán riesgos asociados a desviaciones térmicas, cumplimiento normativo y la trazabilidad como garantía de seguridad y calidad. Veremos cómo la gestión térmica eficiente protege la salud del consumidor, previene pérdidas económicas y fortalece la reputación institucional.

### Contenido y dinámicas prácticas
- Introducción al impacto crítico de la temperatura en vacunas, reactivos, alimentos, productos médicos, entre otros.
- Buenas Prácticas de Almacenamiento (BPA), ISO 17025, lineamientos de la OMS/OPS, entre otros.
- Control en cámaras frías, medios isotermos, transporte y refrigeradoras.
- ¿Qué se pone en riesgo?: Seguridad del paciente, estabilidad del producto, cumplimiento legal y reputación organizacional.
- Servicios clave para el control térmico: Instalación, capacitación, mantenimiento, calibración, validación, IQ/OQ, caracterización y mapeo térmico.

### Lo que obtendrás
- Aprenderás a identificar puntos críticos de control térmico en toda la cadena de frío.
- Conocerás los servicios que aseguran un control efectivo: calibración, mapeo, mantenimiento, validación e instalación.
- Observarás cómo una gestión eficiente mejora la calidad del producto, asegura la trazabilidad y contribuye a la sostenibilidad.
- Descubrirás cómo podemos ayudarte a implementar soluciones integrales en control térmico y cumplimiento normativo.

', 'https://i.ibb.co/V0fNpDbQ/tempc.webp', 'https://i.ibb.co/bRDNCb6v/Mesa-de-trabajo-73-3.png', 12, 60, 40, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(8, '2025-09-02', '16:00-16:45', 'sala4', 'Control de calidad y Análisis de cafeína en producción de café por HPTLC', 'control-de-calidad-y-analisis-de-cafeina-en-produccion-de-cafe-por-hptlc', 'Ing. Eliezer Ceniviva - Jefe de servicio', 'Suiza', 'Encontraremos en esta sesión una mirada especializada al análisis de cafeína como indicador de calidad en productos derivados del café y otras bebidas. Podrás conocer cómo la técnica de cromatografía en capa fina de alta resolución (HPTLC) se posiciona como una herramienta eficaz, rápida y económica para el control de calidad en la industria alimentaria. Observaremos cómo esta metodología permite una cuantificación precisa y simultánea de múltiples muestras, con mínima preparación y bajo impacto ambiental.

## Contenido y dinámicas prácticas  
- **Fundamentos de HPTLC**: Principios básicos de separación y detección de compuestos activos como la cafeína.  
- **Preparación y aplicación de muestras**: Extracción, aplicación en placa, desarrollo y revelado.  
- **Cuantificación y validación**: Cálculo de concentración, curvas de calibración, límites de detección y repetibilidad.  
- **Aplicaciones reales**: Evaluación de cafeína en café tostado, instantáneo, bebidas energéticas y tés.

## Lo que obtendrás  
- Podrás aplicar técnicas HPTLC para determinar cafeína en matrices complejas con alta confiabilidad.  
- Aprenderás a interpretar resultados cromatográficos y validar métodos conforme a normativas.  
- Observarás cómo integrar este análisis en rutinas de control de calidad, contribuyendo a la estandarización de productos en la industria alimentaria.  
', 'https://i.ibb.co/BKdszdpx/cafe-33.webp', 'https://i.ibb.co/dJLTXYSm/Mesa-de-trabajo-85.png', 1, 60, 61, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(9, '2025-09-02', '17:00-17:45', 'sala1', 'Monitoreo Ambiental Activo en la Industria de Alimentos y Bebidas: Prevención, Control y Sostenibilidad', 'monitoreo-microbiologico-continuo-en-areas-de-calidad-y-produccion', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'El monitoreo ambiental microbiológico en la industria de alimentos y bebidas es crucial para garantizar la inocuidad y calidad de los productos. Su importancia radica en:

- **Prevención de contaminación**: Detecta la presencia de microorganismos patógenos o indicadores antes de que contaminen los productos.  
- **Cumplimiento normativo**: Ayuda a cumplir con regulaciones sanitarias y estándares internacionales (como HACCP o ISO 22000).  
- **Protección del consumidor**: Reduce el riesgo de enfermedades transmitidas por alimentos.  
- **Control de procesos**: Permite evaluar la eficacia de las prácticas de higiene y limpieza.  
- **Reputación y confianza**: Previene retiros de productos, pérdidas económicas y daños a la imagen de la marca.  

### Contenido y dinámicas prácticas

- Tecnología Sartorius para monitoreo microbiológico ambiental.  
- Equipos de muestreo activo de aire por filtración y por impactación (MD8 Airport).  

### Lo que obtendrás

- Aprenderás a seleccionar y aplicar tecnologías de Sartorius para el monitoreo microbiológico continuo según tu entorno.  
- Observarás cómo estas soluciones fortalecen los programas de monitoreo ambiental microbiológico y de calidad, optimizando procesos, reduciendo riesgos y asegurando la calidad.

', 'https://i.ibb.co/NPCNZ9B/sart34.webp', 'https://i.ibb.co/zVH8ZngN/Mesa-de-trabajo-67-1.png', 5, 60, 60, 1, '2025-06-05 13:12:07', '["Alimentos", "Salud", "Educación", "Aguas y bebidas", "Pesquera"]'),
(10, '2025-09-02', '17:00-17:45', 'sala2', 'Combustion DUMAS una alternativa sostenible en Analisis de Nitrogeno/Proteina', 'combustion-dumas-una-alternativa-sostenible-en-analisis-de-nitrogeno-proteina', 'Pablo Scarpin - Business Development Manager', 'Argentina', 'Encontraremos en esta sesión una comparativa clara y actualizada entre dos de los métodos más utilizados para la determinación de nitrógeno y proteína en alimentos: Kjeldahl y Dumas. Podrás descubrir cómo la tecnología de combustión Dumas se presenta como una alternativa moderna, rápida y sostenible frente al tradicional método húmedo, eliminando el uso de reactivos corrosivos y reduciendo el impacto ambiental del laboratorio. Observaremos cómo aplicar este cambio puede optimizar tiempos de análisis y elevar la seguridad operativa sin comprometer la precisión.

## Contenido y dinámicas prácticas  
- **Fundamentos de ambos métodos**: Principios químicos de Kjeldahl (digestión ácida) y Dumas (combustión térmica).  
- **Comparación técnica y operativa**: Tiempos de análisis, precisión, consumo de insumos, residuos generados y automatización.  
- **Aplicación en muestras reales**: Análisis práctico en alimentos proteicos (carnes, harinas, legumbres) usando equipos modernos de combustión.  
- **Transición sostenible**: Consideraciones para implementar el cambio de metodología en el laboratorio y cumplir normativas.

## Lo que obtendrás  
- Aprenderás a evaluar qué método se ajusta mejor a tus necesidades analíticas y capacidad operativa.  
- Podrás observar cómo reducir el impacto ambiental sin sacrificar exactitud en la determinación de proteína.  
- Obtendrás criterios técnicos y prácticos para tomar decisiones informadas en tu estrategia de control de calidad.  ', 'https://i.ibb.co/TxFbgLdN/velp-3.webp', 'https://i.ibb.co/9kZ1t7Hy/Mesa-de-trabajo-73.png', 8, 60, 56, 1, '2025-06-05 13:12:07', '["Alimentos", "Educación", "Aguas y bebidas", "Pesquera"]'),
(11, '2025-09-02', '17:00-17:45', 'sala3', 'Importancia de la cadena de frío en los alimentos', 'determinacion-de-vida-util-de-alimentos', 'Ing. Sergio Ayala Luna ', 'México', 'La calidad y seguridad de los alimentos no dependen únicamente de su procesamiento, sino también del control estricto de la temperatura desde su producción hasta su consumo. En esta sesión abordaremos cómo una cadena de frío bien implementada es clave para evitar riesgos microbiológicos, conservar propiedades nutricionales y garantizar la vida útil esperada de los productos alimenticios.

## Lo que aprenderás  
- Cómo se define y controla una cadena de frío eficiente en la industria alimentaria.  
- Principales puntos críticos de control térmico en almacenamiento, transporte y distribución.  
- Impacto del quiebre de cadena sobre la seguridad alimentaria y percepción del consumidor.  
- Tecnologías actuales para monitoreo y trazabilidad de temperatura.

## ¿Por qué asistir?  
- Podrás identificar vulnerabilidades en tu proceso de conservación.  
- Obtendrás herramientas para garantizar cumplimiento normativo y reducción de pérdidas.  
- Conocerás ejemplos aplicados de mejora en la cadena de frío con soluciones sostenibles y eficientes.
', 'https://i.ibb.co/4nrHphWy/image.png', 'https://i.ibb.co/N2B21ZRQ/Mesa-de-trabajo-73-copia.png', NULL, 60, 89, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(12, '2025-09-02', '17:00-17:45', 'sala4', 'Análisis de nitritos, nitratos, cloruro sódifco y fosfátos en extractos cárnicos', 'analisis-de-nitritos-nitratos-cloruro-sodifco-y-fosfatos-en-extractos-carnicos', 'Qco. James Rojas Sanchez', 'Perú', 'Podrás explorar cómo, con el respaldo de la tecnología de la marca **AMS**, el análisis preciso de nitritos, nitratos, cloruro sódico y fosfatos en extractos cárnicos se vuelve más accesible, confiable y reproducible. Encontraremos en esta sesión cómo los equipos y soluciones de AMS permiten realizar determinaciones rápidas y exactas en matrices complejas, respondiendo a los estándares de calidad más exigentes del sector alimentario. Observaremos cómo estos análisis contribuyen a la optimización de formulaciones, asegurando la seguridad del consumidor y el cumplimiento normativo.

## Contenido y dinámicas prácticas  
- **Importancia del control de aditivos**: Rol funcional de cada compuesto (conservación, sabor, textura) y sus límites regulatorios.  
- **Tecnologías AMS aplicadas**: Equipos de análisis fotométrico,
', 'https://i.ibb.co/8gK8sxC9/amns-s.webp', 'https://i.ibb.co/93rVQCN8/Mesa-de-trabajo-88.png', 10, 60, 56, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(13, '2025-09-02', '18:00-18:45', 'sala1', 'Determinación de Vida Útil de Alimentos ', 'determinacion-de-vida-util-de-alimentos-2', 'PhD. Fernando Vargas', 'Perú', 'Podrás descubrir cómo la determinación de la vida útil de alimentos va mucho más allá del diseño del empaque: involucra un control climático riguroso que garantiza la estabilidad, calidad y frescura del producto a lo largo del tiempo. Encontraremos en esta sesión las variables críticas que influyen en la degradación de alimentos —como temperatura, humedad, luz y exposición al oxígeno— y cómo simular condiciones reales de almacenamiento para predecir de forma precisa su comportamiento. Observaremos cómo el uso de cámaras climáticas, sistemas de monitoreo y ensayos acelerados permiten tomar decisiones basadas en datos confiables.

## Contenido y dinámicas prácticas  
- **Factores que afectan la vida útil**: Revisión de parámetros físicos, químicos y microbiológicos que inciden en la estabilidad del producto.  
- **Diseño de estudios de vida útil**: Métodos acelerados vs. tiempo real, selección de condiciones y frecuencia de muestreo.  
- **Tecnologías de control climático**: Uso de cámaras de estabilidad, sensores inteligentes y sistemas de trazabilidad ambiental.  
- **Interpretación de resultados**: Modelado de datos, estimación del vencimiento y validación de fecha de consumo preferente.

## Lo que obtendrás  
- Aprenderás a diseñar e implementar estudios de vida útil basados en condiciones controladas y realistas.  
- Podrás identificar los puntos críticos que afectan la conservación del producto y cómo mitigarlos.  
- Observarás cómo un enfoque integral de control climático fortalece el desarrollo de productos y la confianza del consumidor.  
', 'https://i.ibb.co/FkKyr70C/binder-112.webp', 'https://i.ibb.co/trJSMyP/Mesa-de-trabajo-67-copia.png', 7, 70, 113, 1, '2025-06-05 13:12:07', '["Alimentos"]'),
(14, '2025-09-02', '18:00-18:45', 'sala2', 'Metodo Randall: la metodologia del futuro contra el impacto ambiental', 'metodo-randall-la-metodologia-del-futuro-contra-el-impacto-ambiental', 'Pablo Scarpin - Business Development Manager', 'Argentina', 'Podrás descubrir cómo el método Randall se posiciona como una alternativa moderna y sostenible frente a los métodos tradicionales de extracción por solvente, como el Soxhlet clásico. Encontraremos en esta charla cómo esta técnica optimiza tiempo, consumo energético y uso de solventes orgánicos, convirtiéndose en una herramienta clave para laboratorios comprometidos con el medio ambiente. Observaremos cómo su eficiencia no solo reduce el impacto ambiental, sino que también mejora la productividad sin comprometer la precisión analítica.

## Contenido y dinámicas prácticas  
- **Fundamentos del método Randall**: Principios de calentamiento, reflujo y recuperación rápida de solventes.  
- **Comparación con técnicas tradicionales**: Ventajas frente al método Soxhlet en términos de tiempo, seguridad y sostenibilidad.  
- **Aplicaciones analíticas**: Extracción de grasas en alimentos, residuos en matrices vegetales y determinaciones ambientales.  
- **Reducción del impacto ambiental**: Menor generación de residuos, ahorro energético y reutilización de solventes.

## Lo que obtendrás  
- Aprenderás a aplicar el método Randall en distintos tipos de análisis con resultados reproducibles y eficientes.  
- Podrás evaluar el ahorro de recursos frente a métodos convencionales en tus procesos de laboratorio.  
- Observarás cómo integrar esta técnica en tu estrategia de laboratorio verde, alineándote con prácticas más sostenibles.  
', 'https://i.ibb.co/Qv2mB9qV/velp-4.webp', 'https://i.ibb.co/7t1RjTjd/Mesa-de-trabajo-73-1.png', 8, 60, 69, 1, '2025-06-05 13:12:07', '["Educación", "Alimentos", "Pesquera"]'),
(15, '2025-09-02', '18:00-18:45', 'sala3', 'De la Microscopía Óptica Clásica a la Confocal 3D de Alta Resolución', 'de-la-microscopia-optica-clasica-a-la-confocal-3d-de-alta-resolucion', 'Mario Esteban Muñoz - Business Unit Leader', 'Colombia', 'Podrás recorrer la evolución tecnológica que ha transformado la microscopía óptica clásica en un potente sistema de visualización tridimensional con resolución submicrométrica. Encontraremos en esta sesión cómo la microscopía confocal ha revolucionado el análisis de estructuras biológicas y materiales complejos, permitiendo observar detalles invisibles para los métodos convencionales. Observaremos cómo esta tecnología no solo mejora la resolución, sino que permite secciones ópticas precisas, reconstrucciones 3D y análisis cuantitativos avanzados.

## Contenido y dinámicas prácticas  
- **Principios de la microscopía confocal**: Diferencias clave con la microscopía óptica tradicional y ventajas en contraste y profundidad.  
- **Tecnología de escaneo y detección**: Láseres, pinhole, detectores y sistemas de reconstrucción de imagen 3D.  
- **Aplicaciones multidisciplinarias**: Biología celular, análisis de tejidos, materiales compuestos, polímeros y superficies.  
- **Interpretación de imágenes y datos**: Generación de secciones ópticas, análisis de volumen y cuantificación de estructuras internas.

## Lo que obtendrás  
- Aprenderás a reconocer las diferencias funcionales entre sistemas ópticos clásicos y confocales.  
- Podrás comprender el valor del análisis 3D en investigaciones avanzadas o caracterización de materiales.  
- Observarás cómo esta tecnología mejora la capacidad de detección y análisis en diversas áreas científicas e industriales.  
', 'https://i.ibb.co/gMfh0qFX/evidnent-3.webp', 'https://i.ibb.co/yFXvNnQn/Mesa-de-trabajo-79.png', 2, 70, 79, 1, '2025-06-05 13:12:07', '["Alimentos", "Salud", "Educación", "Farmacéutica"]'),
(16, '2025-09-02', '18:00-18:45', 'sala4', 'Termobalanza por infrarrojo: Optimización del tiempo en la determinación de humedad', 'termobalanza-por-infrarrojo-una-solucion-ecoamigable-con-el-ambiente-y-tu-muestra', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Podrás descubrir cómo las termobalanzas por infrarrojo representan una solución ecoamigable, precisa y eficiente para el análisis de humedad en distintos tipos de muestras. Encontraremos en este taller práctico cómo esta tecnología permite obtener resultados rápidos sin necesidad de reactivos ni procesos destructivos, cuidando tanto el entorno como la integridad del laboratorio. Observaremos cómo su uso optimiza el control de calidad en alimentos, productos farmacéuticos, agrícolas e industriales, reduciendo tiempos y residuos.

## Contenido y dinámicas prácticas  
- **Fundamentos del secado por infrarrojo**: Principios de funcionamiento, tipos de fuentes térmicas y ventajas frente a métodos tradicionales.  
- **Configuración y operación de la termobalanza**: Programación de parámetros, tiempos de análisis, curvas de secado y perfiles personalizados.  
- **Aplicaciones prácticas**: Determinación de humedad en harinas, productos deshidratados, polímeros, minerales y más.  
- **Sostenibilidad en el análisis**: Eliminación de reactivos químicos, bajo consumo energético y reducción de residuos sólidos.

## Lo que obtendrás  
- Aprenderás a utilizar correctamente una termobalanza por infrarrojo, maximizando su rendimiento y precisión.  
- Podrás interpretar curvas de pérdida de masa para tomar decisiones técnicas en tiempo real.  
- Observarás cómo esta tecnología se integra en un enfoque sostenible, eficiente y adaptable a múltiples industrias.  
', 'https://i.ibb.co/S7B44CSW/ma1603-copia.webp', 'https://www.kossomet.com/AppUp/expokossodo/adds/526028732_1105481944842081_1174411080702905176_n.jpeg', 5, 60, 59, 1, '2025-06-05 13:12:07', '["Alimentos", "Pesquera"]'),
(21, '2025-09-03', '15:00-15:45', 'sala1', 'Optimización de la producción del agua para laboratorio', 'optimizacion-de-la-produccion-del-agua-para-laboratorio', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', '
Podrás descubrir cómo optimizar la producción de agua purificada y ultrapura es esencial para garantizar la confiabilidad de los análisis en la industria farmacéutica. Encontraremos en esta sesión una revisión detallada de los tipos de agua requeridos (Tipo I, II, III), sus aplicaciones específicas en el laboratorio, y cómo asegurar el cumplimiento de normativas internacionales. Observaremos cómo una gestión eficiente del sistema de purificación no solo mejora la calidad del agua, sino también reduce costos operativos, tiempos muertos y riesgos de contaminación cruzada.

### Contenido y dinámicas prácticas  
- **Tipos de agua y sus aplicaciones**: Agua para inyectables, para análisis instrumental, preparación de reactivos y en procesos de limpieza.  
- **Tecnologías de purificación**: Osmosis inversa, electrodeionización, UV y ultrafiltración.  
- **Normativas aplicables**: Requisitos de farmacopeas (USP, EP) y validación de calidad de agua.  
- **Mantenimiento y monitoreo**: Estrategias para asegurar una producción continua y confiable con bajo impacto ambiental.
', 'https://i.ibb.co/d0SWrrDz/sart-puriif.webp', 'https://www.kossomet.com/AppUp/expokossodo/adds/525868733_758967853516034_5496769438477949467_n.jpeg', 5, 60, 61, 1, '2025-06-05 13:12:07', '["Farmacéutica", "Salud", "Educación", "Alimentos", "Aguas y bebidas"]'),
(22, '2025-09-03', '15:00-15:45', 'sala2', 'Sistemas de control de temperatura precisos y de bajo impacto ambiental ', 'sistemas-de-control-de-temperatura-precisos-y-de-bajo-impacto-ambiental-2', 'Andre Sautchuk - Managing Director', 'Brazil', 'Podrás descubrir cómo los sistemas de control de temperatura modernos están transformando los laboratorios de alimentos hacia una operación más precisa, eficiente y sostenible. Encontraremos en esta sesión cómo tecnologías de calefacción y refrigeración de última generación no solo aseguran condiciones estables para los análisis, sino que también reducen significativamente el consumo energético y la huella ambiental. Observaremos cómo un laboratorio puede optimizar sus procesos térmicos sin comprometer la calidad, integrando soluciones responsables con el entorno.

## Contenido y dinámicas prácticas  
- **Tecnología para un laboratorio sostenible**: Equipos de recirculación, baños termostatados y enfriadores con eficiencia energética mejorada.  
- **Control térmico en aplicaciones críticas**: Estabilidad en análisis de viscosidad, pruebas de estabilidad térmica, conservación de muestras y más.  
- **Reducción del impacto ambiental**: Sistemas con refrigerantes ecológicos, bajo consumo eléctrico y diseño optimizado para uso prolongado.  
- **Estrategias de mejora continua**: Monitoreo inteligente de temperatura, mantenimiento preventivo y selección de equipos con certificaciones verdes.

## Lo que obtendrás  
- Aprenderás a identificar soluciones térmicas que se adapten a tus necesidades analíticas y sostenibilidad corporativa.  
- Podrás mejorar la eficiencia energética del laboratorio y reducir costos operativos sin sacrificar precisión.  
- Observarás cómo implementar una cultura de mejora ambiental desde el control de temperatura hasta la gestión de procesos más amplios.  
', 'https://i.ibb.co/7JLMdZfP/laud-3.webp', 'https://i.ibb.co/TxQdS1JN/Mesa-de-trabajo-110.png', 6, 60, 37, 1, '2025-06-05 13:12:07', '["Farmacéutica", "Educación"]'),
(23, '2025-09-03', '15:00-15:45', 'sala3', 'Importancia de selección de columnas HPLC en análisis de fármacos', 'importancia-de-seleccion-de-columnas-hplc-en-analisis-de-farmacos', 'Qco. James Rojas Sanchez - Asesor Técnico', 'Perú', 'Podrás descubrir cómo la correcta selección de columnas en HPLC es un factor determinante para lograr separaciones eficientes, reproducibles y conforme a los estándares exigidos en el análisis de fármacos. Encontraremos en este taller práctico los criterios fundamentales para elegir la columna más adecuada según la naturaleza del analito, la matriz y el objetivo del método. Observaremos cómo variaciones en la fase estacionaria, el tamaño de partícula o la dimensión de la columna pueden afectar directamente la resolución, el tiempo de análisis y la sensibilidad.

## Contenido y dinámicas prácticas  
- **Tipos de columnas y fases estacionarias**: Revisión de C18, fenil, CN, HILIC y otras fases utilizadas en análisis farmacéutico.  
- **Factores críticos de selección**: pH, polaridad, tipo de compuesto, carga iónica y compatibilidad con el detector.  
- **Optimización del método cromatográfico**: Influencia del tamaño de partícula, longitud y diámetro de columna en la eficiencia y presión del sistema.  
- **Estudio de casos reales**: Comparación práctica de resultados usando diferentes columnas para un mismo principio activo.

## Lo que obtendrás  
- Aprenderás a seleccionar columnas HPLC con base técnica y estratégica para análisis de ingredientes farmacéuticos activos (APIs).  
- Podrás identificar problemas comunes de separación y cómo resolverlos mediante el cambio o ajuste de columna.  
- Observarás cómo una correcta elección de columna mejora la productividad del laboratorio y asegura el cumplimiento regulatorio.  
', 'https://i.ibb.co/V0Kp4syC/colgumna-hplc.webp', 'https://i.ibb.co/d9wPxm9/Mesa-de-trabajo-109-copia.png', NULL, 60, 92, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(24, '2025-09-03', '15:00-15:45', 'sala4', 'Temperatura Bajo Control: Seguridad y Calidad en Cada Grado', 'temperatura-bajo-control-seguridad-y-calidad-en-cada-grado-2', 'Daniel Torres', 'Venezuela', 'Descubre cómo una gestión adecuada de la temperatura es esencial para la integridad de productos sensibles y la sostenibilidad de procesos. Esta capacitación mostrará la importancia de monitorear y controlar condiciones térmicas en medios isotermos, almacenes y equipos de conservación. Se abordarán riesgos asociados a desviaciones térmicas, cumplimiento normativo y la trazabilidad como garantía de seguridad y calidad. Veremos cómo la gestión térmica eficiente protege la salud del consumidor, previene pérdidas económicas y fortalece la reputación institucional.

### Contenido y dinámicas prácticas
- Introducción al impacto crítico de la temperatura en vacunas, reactivos, alimentos, productos médicos, entre otros.
- Buenas Prácticas de Almacenamiento (BPA), ISO 17025, lineamientos de la OMS/OPS, entre otros.
- Control en cámaras frías, medios isotermos, transporte y refrigeradoras.
- ¿Qué se pone en riesgo?: Seguridad del paciente, estabilidad del producto, cumplimiento legal y reputación organizacional.
- Servicios clave para el control térmico: Instalación, capacitación, mantenimiento, calibración, validación, IQ/OQ, caracterización y mapeo térmico.

### Lo que obtendrás
- Aprenderás a identificar puntos críticos de control térmico en toda la cadena de frío.
- Conocerás los servicios que aseguran un control efectivo: calibración, mapeo, mantenimiento, validación e instalación.
- Observarás cómo una gestión eficiente mejora la calidad del producto, asegura la trazabilidad y contribuye a la sostenibilidad.
- Descubrirás cómo podemos ayudarte a implementar soluciones integrales en control térmico y cumplimiento normativo.


', 'https://i.ibb.co/V0fNpDbQ/tempc.webp', 'https://i.ibb.co/RTSGqffY/Mesa-de-trabajo-132.png', 12, 60, 27, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(25, '2025-09-03', '16:00-16:45', 'sala1', 'Micropipetas Electrónicas: Precisión y Eficiencia en el Laboratorio', 'micropipetas-electronicas-precision-y-eficiencia-en-el-laboratorio', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Podrás descubrir cómo las micropipetas electrónicas están revolucionando el trabajo de laboratorio al ofrecer una combinación ideal de precisión, repetibilidad y eficiencia operativa. Encontraremos en esta sesión cómo estas herramientas avanzadas ayudan a reducir errores humanos, mejorar la ergonomía del trabajo repetitivo y optimizar el flujo de tareas en entornos analíticos exigentes. Observaremos cómo sus funciones programables, modos múltiples y calibración digital elevan la calidad y confiabilidad de cada resultado.

## Contenido y dinámicas prácticas  
- **Ventajas frente a micropipetas manuales**: Reducción de variabilidad entre usuarios, disminución del esfuerzo físico y mayor control del volumen dispensado.  
- **Modos de trabajo y funciones inteligentes**: Pipeteo estándar, mezcla, dispensación en serie, diluciones y ciclos programables.  
- **Calibración y mantenimiento**: Verificación del rendimiento, ajustes digitales y recomendaciones de cuidado para prolongar su vida útil.  
- **Aplicaciones prácticas**: Uso en laboratorios de biología molecular, microbiología, farmacéutica, análisis clínico y control de calidad.

## Lo que obtendrás  
- Aprenderás a utilizar micropipetas electrónicas para tareas complejas con mayor velocidad y precisión.  
- Podrás programar y personalizar funciones que se ajusten a tu flujo de trabajo.  
- Observarás cómo esta tecnología mejora la productividad del laboratorio, minimiza el error humano y protege la salud del usuario.  
', 'https://i.ibb.co/TMLGGp5v/Sin-t-tulo-3.webp', 'https://www.kossomet.com/AppUp/expokossodo/adds/527058768_1128161782703260_2417773421700944128_n.jpeg', 5, 60, 60, 1, '2025-06-05 13:12:07', '["Farmacéutica", "Salud", "Educación", "Alimentos"]'),
(26, '2025-09-03', '16:00-16:45', 'sala2', 'Decisiones que salvan: cómo elegir la cabina de bioseguridad ideal', 'decisiones-que-salvan-como-elegir-la-cabina-de-bioseguridad-ideal', 'Wilmer Matta / Ing. Milagros Passaro', 'Perú', 'Podrás descubrir cómo una decisión informada en la elección de una cabina de bioseguridad puede marcar la diferencia entre un entorno seguro y uno vulnerable en tu laboratorio. Encontraremos en esta guía práctica los criterios esenciales para seleccionar la cabina ideal según el tipo de riesgo biológico, los procesos a realizar y el nivel de protección requerido para el operador, el producto y el ambiente. Observaremos cómo el cumplimiento de normativas internacionales y las buenas prácticas en la instalación y uso aseguran una protección efectiva y sostenible.

## Contenido y dinámicas prácticas  
- **Clasificación de cabinas de bioseguridad**: Diferencias entre Clase I, II y III, niveles de contención y tipos de protección ofrecida.  
- **Evaluación de riesgos y procesos**: Cómo identificar la cabina adecuada según el tipo de muestra, agente biológico y manipulación requerida.  
- **Normativas y certificaciones clave**: Revisión de estándares como NSF/ANSI 49, EN 12469 y normativas de bioseguridad aplicables.  
- **Aspectos técnicos y operativos**: Requisitos de instalación, flujo de aire, filtros HEPA, mantenimiento y validación de desempeño.

## Lo que obtendrás  
- Aprenderás a seleccionar la cabina correcta para tu aplicación específica con base en riesgos reales y requisitos técnicos.  
- Podrás interpretar las certificaciones y parámetros críticos que garantizan la eficacia del equipo.  
- Observarás cómo una elección adecuada mejora la bioseguridad del laboratorio y facilita el cumplimiento normativo.  
', 'https://i.ibb.co/35DWg54d/escasss-sd.webp', 'https://i.ibb.co/G45wGjqT/Mesa-de-trabajo-118.png', 3, 60, 58, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(27, '2025-09-03', '16:00-16:45', 'sala3', 'Más allá del calor: cómo el control térmico impacta tu producto cosmético', 'mas-alla-del-calor-como-el-control-termico-impacta-tu-producto-cosmetico', 'Guillermo Casanovas', 'Argentina ', 'Podrás descubrir cómo el control térmico va mucho más allá de un simple parámetro de proceso: es un pilar fundamental en la estabilidad, eficacia y reproducibilidad de productos cosméticos. Encontraremos en esta sesión cómo pequeñas variaciones de temperatura pueden afectar la textura, color, fragancia o comportamiento funcional de cremas, geles, emulsiones y otros cosméticos. Observaremos cómo una gestión térmica precisa durante el desarrollo, producción y almacenamiento garantiza un producto final de alta calidad y cumplimiento regulatorio.

## Contenido y dinámicas prácticas  
- **Factores térmicos críticos en cosmética**: Impacto de la temperatura en la emulsificación, conservación y compatibilidad de ingredientes.  
- **Tecnologías de control de temperatura**: Equipos de recirculación, baños termostatados, cámaras climáticas y sensores inteligentes.  
- **Estudios de estabilidad y vida útil**: Cómo simular condiciones ambientales extremas para validar comportamiento y desempeño del producto.  
- **Buenas prácticas en procesos térmicos**: Monitoreo continuo, validación de parámetros y registros trazables.

## Lo que obtendrás  
- Aprenderás a identificar puntos clave donde la temperatura influye directamente en la calidad del cosmético.  
- Podrás aplicar herramientas de control térmico para optimizar formulaciones y procesos.  
- Observarás cómo una estrategia térmica bien gestionada mejora la consistencia del producto y la confianza del consumidor.  
', 'https://i.ibb.co/mrjJK82t/bind-444.webp', 'https://i.ibb.co/FqhywZ0q/Mesa-de-trabajo-109-copia-2.png', 7, 60, 11, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(28, '2025-09-03', '16:00-16:45', 'sala4', 'Determinación de la cafeína en las pastillas analgésicas por técnica HPTLC', 'determinacion-de-la-cafeina-en-las-pastillas-analgesicas-por-tecnica-hptlc', 'Ing. Eliezer Ceniviva - Jefe de servicio', 'Suiza', 'Podrás descubrir cómo la cromatografía HPTLC (capa fina de alta resolución) se posiciona como una técnica confiable, versátil y rentable para el análisis cualitativo y cuantitativo de principios activos en formulaciones farmacéuticas. Encontraremos en esta sesión cómo aplicar esta metodología en la determinación de cafeína en pastillas analgésicas, aprovechando su capacidad para procesar múltiples muestras en paralelo, con bajo consumo de reactivos y excelente reproducibilidad. Observaremos cómo la HPTLC permite visualizar, comparar y cuantificar componentes activos de forma sencilla, cumpliendo con los requisitos de control de calidad y validación analítica.

## Contenido y dinámicas prácticas  
- **Fundamentos de la técnica HPTLC**: Separación por adsorción en placa, desarrollo cromatográfico y detección UV o química.  
- **Preparación y análisis de comprimidos**: Disolución, extracción, aplicación en placa, revelado y comparación con estándares de referencia.  
- **Ventajas en el análisis de fármacos**: Análisis simultáneo de múltiples muestras, alta repetibilidad y validación según farmacopeas.  
- **Aplicaciones reguladas**: Control de calidad de medicamentos, estudios de estabilidad, identificación de ingredientes activos y verificación de contenidos.

## Lo que obtendrás  
- Aprenderás a implementar el análisis de cafeína y otros compuestos farmacéuticos usando HPTLC de manera precisa y eficiente.  
- Podrás comparar esta técnica con métodos instrumentales más complejos en términos de costo, tiempo y facilidad de uso.  
- Observarás cómo la HPTLC puede integrarse eficazmente en el control de calidad de laboratorios farmacéuticos.  
', 'https://i.ibb.co/RGBzK6tC/past3.webp', 'https://i.ibb.co/Y4rKDPDs/Mesa-de-trabajo-85-1.png', 1, 60, 26, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(29, '2025-09-03', '17:00-17:45', 'sala1', 'Balanzas de laboratorio con conciencia ecológica y trazabilidad', 'balanzas-de-laboratorio-con-conciencia-ecologica', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Descubre cómo las nuevas generaciones de balanzas de laboratorio no solo mejoran la precisión del pesaje, sino que también contribuyen a una operación más sostenible, eficiente y trazable. Esta sesión te permitirá conocer cómo integrar criterios ecológicos en tu flujo de trabajo sin comprometer el rendimiento analítico.

## Lo que podrás observar  
- Características de diseño que reducen el consumo energético y la huella ecológica.  
- Funcionalidades que facilitan un manejo intuitivo, reduciendo errores humanos y tiempos de entrenamiento.  
- Integración con sistemas digitales para garantizar trazabilidad, cumplimiento normativo y protección de datos.  

## ¿Por qué es relevante?  
Porque en un laboratorio moderno, eficiencia y sostenibilidad deben ir de la mano. Esta charla te dará una visión clara sobre cómo elegir el equipo adecuado para cumplir con tus objetivos operativos, regulatorios y ambientales.
', 'https://i.ibb.co/0ycwBYn8/balanza-232-2.webp', 'https://www.kossomet.com/AppUp/expokossodo/adds/526308233_718779271154466_3329208073872452750_n.jpeg', 5, 60, 41, 1, '2025-06-05 13:12:07', '["Farmacéutica", "Salud", "Química & Petrolera", "Aguas y bebidas", "Educación", "Alimentos", "Minería", "Pesquera"]'),
(30, '2025-09-03', '17:00-17:45', 'sala2', 'Desde la formulación hasta la estabilidad: el vacío como aliado ', 'desde-la-formulacion-hasta-la-estabilidad-el-vacio-como-aliado', 'Dr. Roberto Friztler', 'Alemania', 'Podrás descubrir cómo el vacío se convierte en un aliado clave en las distintas etapas del desarrollo de productos, desde la formulación hasta los estudios de estabilidad. Encontraremos en esta sesión cómo la aplicación de vacío controlado permite mejorar la homogeneidad, eliminar burbujas, acelerar el secado y conservar la integridad de ingredientes sensibles. Observaremos cómo esta tecnología no solo optimiza los procesos físicos y químicos, sino que también contribuye a garantizar la calidad, estabilidad y apariencia del producto final.

## Contenido y dinámicas prácticas  
- **Vacío en formulación**: Eliminación de aire atrapado, mezcla homogénea y mejora en la dispersión de activos.  
- **Vacío en procesos de secado**: Secado a bajas temperaturas para proteger ingredientes termo-sensibles y mejorar la eficiencia energética.  
- **Vacío en estudios de estabilidad**: Simulación de condiciones críticas para validar vida útil, envase y comportamiento físico del producto.  
- **Equipos y configuraciones recomendadas**: Tipos de bombas, cámaras y accesorios adaptables a laboratorio e industria.

## Lo que obtendrás  
- Aprenderás a identificar puntos clave donde el vacío mejora procesos en cosmética, farmacéutica y alimentos.  
- Podrás aplicar técnicas de vacío para incrementar calidad, reducir tiempos y conservar propiedades funcionales.  
- Observarás cómo esta tecnología contribuye a una producción más controlada, reproducible y eficiente.  ', 'https://i.ibb.co/m5KHf9vc/vaccss.webp', 'https://i.ibb.co/q3SKjqWq/Mesa-de-trabajo-102-1.png', 4, 60, 58, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(31, '2025-09-03', '17:00-17:45', 'sala3', 'Cuartos ambientales pára estabilidad de medicamentos', 'mas-alla-del-calor-como-el-control-termico-impacta-tu-producto-cosmetico-2', 'Ing. Sergio Ayala Luna', 'México', 'Podrás descubrir cómo los cuartos ambientales son esenciales en la industria farmacéutica para realizar estudios de estabilidad que aseguren la eficacia, seguridad y calidad de los medicamentos a lo largo del tiempo. Encontraremos en esta sesión cómo estas instalaciones permiten reproducir condiciones ambientales controladas —como temperatura, humedad y luz— conforme a normativas internacionales, y cómo su diseño influye directamente en la validez de los datos generados. Observaremos cómo implementar un cuarto de estabilidad adecuado es clave para cumplir con las guías ICH y los requerimientos regulatorios de agencias sanitarias.

## Contenido y dinámicas prácticas  
- **Normativas aplicables**: ICH Q1A(R2) y sus requisitos para estudios de estabilidad acelerada, de larga duración e intermedios.  
- **Diseño y control de los cuartos ambientales**: Equipos de climatización, sistemas de monitoreo continuo y validación de condiciones críticas.  
- **Parámetros típicos de prueba**: 25 °C/60 %HR, 30 °C/65 %HR, 40 °C/75 %HR y otros perfiles según destino del producto.  
- **Buenas prácticas de operación**: Calificación de instalaciones (DQ, IQ, OQ, PQ), documentación, alarmas y mantenimiento preventivo.

## Lo que obtendrás  
- Aprenderás cómo funcionan y se gestionan los cuartos ambientales para estudios de estabilidad.  
- Podrás aplicar criterios técnicos y regulatorios para validar tus condiciones de almacenamiento.  
- Observarás cómo estas instalaciones aseguran la vida útil del medicamento bajo condiciones reales y controladas.  
', 'https://i.ibb.co/yvxQWJ8/binder-2323.webp', 'https://i.ibb.co/ns2G78rt/Mesa-de-trabajo-109.png', NULL, 60, 28, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(32, '2025-09-03', '17:00-17:45', 'sala4', 'Bioseguridad con Propósito: Cómo Garantizar Cabinas Seguras y Eficientes', 'bioseguridad-con-proposito-como-garantizar-cabinas-seguras-y-eficientes', 'Daniel Torres', 'Venezuela', 'Explora cómo las cabinas de bioseguridad pueden operar bajo estrictos estándares de seguridad y sostenibilidad, cumpliendo con normativas internacionales como NSF/ANSI 49 y EN 12469. Conoce la importancia de la instalación, mantenimiento, certificación y capacitación especializada para prevenir riesgos, reducir costos operativos y asegurar la protección del usuario y del medio ambiente.

### Contenido y dinámicas prácticas
- Introducción al concepto y tipos de cabinas de bioseguridad.
- Importancia del cumplimiento normativo: NSF/ANSI 49, EN 12469 e ISO 14644.
- Servicios esenciales: instalación, capacitación técnica, mantenimiento, descontaminación con H₂O₂ y certificación.
- Impactos positivos en la operación: reducción de fallas, aumento de vida útil, eficiencia energética.
- Casos prácticos: errores comunes y cómo evitarlos mediante buenas prácticas y soporte técnico especializado.

### Lo que obtendrás
- Aprenderás a identificar y evitar errores frecuentes en el uso de cabinas de bioseguridad.
- Conocerás servicios técnicos avanzados que garantizan el cumplimiento normativo y eficiencia operativa.
- Verás ejemplos reales de mejora tras aplicar soluciones técnicas especializadas.
- Descubrirás cómo KOSSOMET puede ayudarte a implementar prácticas sostenibles y seguras en bioseguridad.
', 'https://i.ibb.co/GfQhnfxp/esccs.webp', 'https://i.ibb.co/67CtkB35/Mesa-de-trabajo-73-4.png', 12, 60, 61, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(33, '2025-09-03', '18:00-18:45', 'sala1', 'Monitoreo Microbiológico Continuo en Áreas ISO5', 'monitoreo-microbiologico-continuo-en-areas-de-calidad-y-produccion-2', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'El monitoreo ambiental microbiológico del aire en salas limpias y áreas controladas en el entorno (c)GMP para microorganismos viables es una tarea rutinaria en la industria farmacéutica y biotecnológica. Como regla general, la recopilación de datos y el posterior análisis de los resultados permiten reconocer tendencias de manera temprana y prevenir desvíos futuros con los niveles de carga biológica que superan los límites.

### Contenido y dinámicas prácticas

- Tecnología Sartorius para monitoreo microbiológico ambiental.  
- Equipos de muestreo activo continuo de aire por filtración (MD8 Airscan®).  
- Equipos de muestreo activo por impactación y filtración (MD8 Airport).  
- **Aplicaciones en ambientes regulados**: Uso en salas limpias, zonas de producción estéril, laboratorios de microbiología y áreas críticas de control de calidad.  
- Cumplimiento de normativas.  

### Lo que obtendrás

- Aprenderás a seleccionar y aplicar tecnologías de Sartorius para el monitoreo microbiológico continuo según tu entorno.  
- Observarás cómo estas soluciones fortalecen los programas de monitoreo ambiental microbiológico y de calidad, optimizando procesos y reduciendo riesgos.
', 'https://i.ibb.co/NPCNZ9B/sart34.webp', 'https://www.kossomet.com/AppUp/expokossodo/adds/525622651_1080350400828897_2132612582130955140_n.jpeg', 5, 60, 39, 1, '2025-06-05 13:12:07', '["Salud", "Educación", "Farmacéutica"]'),
(34, '2025-09-03', '18:00-18:45', 'sala2', 'Evolución de la Microscopía: Óptica Clásica hacia Confocal 3D de Máxima Precisión', 'evolucion-de-la-microscopia-optica-clasica-hacia-confocal-3d-de-maxima-precision', 'Mario Esteban Muñoz - Business Unit Leade', 'Colombia', 'Podrás descubrir cómo la evolución de la microscopía, impulsada por la innovación tecnológica de la marca Evident, ha llevado a los laboratorios desde el análisis óptico clásico hasta la obtención de imágenes tridimensionales de altísima resolución. Encontraremos en esta sesión cómo la microscopía confocal permite visualizar estructuras internas con precisión submicrométrica, reduciendo el ruido de fondo y mejorando el contraste en muestras biológicas, industriales o de materiales complejos. Observaremos cómo estas herramientas de última generación potencian la investigación y el análisis cuantitativo en múltiples disciplinas.

## Contenido y dinámicas prácticas  
- **Transición de óptico convencional a confocal**: Ventajas clave en resolución axial, eliminación de planos fuera de foco y profundidad de campo.  
- **Tecnología Evident en microscopía confocal**: Sistemas láser, escaneo preciso, detección multicanal y software avanzado para reconstrucción 3D.  
- **Aplicaciones en investigación y control de calidad**: Biología celular, neurociencia, ciencia de materiales, cosmética y farmacéutica.  
- **Generación y análisis de imágenes 3D**: Reconstrucción volumétrica, segmentación, cuantificación y visualización interactiva de datos.

## Lo que obtendrás  
- Aprenderás cómo funcionan los sistemas de microscopía confocal Evident y qué los diferencia de otros métodos de análisis óptico.  
- Podrás identificar sus ventajas para investigaciones avanzadas, validación estructural y caracterización de superficies.  
- Observarás cómo la imagen 3D de alta resolución mejora la comprensión de estructuras complejas y la calidad de tus resultados.  
', 'https://i.ibb.co/gMfh0qFX/evidnent-3.webp', 'https://i.ibb.co/Q79byqmq/Mesa-de-trabajo-79-1.png', 2, 60, 42, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(35, '2025-09-03', '18:00-18:45', 'sala3', 'Todo lo que usted quiera saber de la fotoestabilidad ICH Q1B y no se atrevía a preguntar', 'luz-bajo-control-lo-esencial-sobre-estudios-de-fotoestabilidad-segun-la-ich-q1b', 'Ing. Sergio Ayala Luna', 'México', 'Podrás descubrir cómo realizar estudios de fotoestabilidad de manera correcta y conforme a la normativa internacional ICH Q1B es esencial para garantizar la seguridad, eficacia y calidad de productos farmacéuticos expuestos a la luz. Encontraremos en esta sesión los aspectos clave que deben considerarse al diseñar y ejecutar estos ensayos, desde la selección del tipo de iluminación hasta la validación de condiciones críticas. Observaremos cómo un mal control de este parámetro puede comprometer la estabilidad del producto, generar resultados inválidos y afectar negativamente su aprobación regulatoria.

## Contenido y dinámicas prácticas  
- **Fundamentos de la norma ICH Q1B**: Requisitos para estudios de fotoestabilidad tipo I y II, condiciones de exposición y controles obligatorios.  
- **Diseño del ensayo**: Elección del tipo de muestra, materiales del envase, uso de estándares internos y condiciones de iluminación (lux/h, UVA).  
- **Identificación de productos de degradación**: Herramientas analíticas para evaluar los efectos de la luz y cómo interpretar los resultados.  
- **Buenas prácticas para evitar errores comunes**: Validación de la cámara de luz, calibración de sensores y documentación adecuada del ensayo.

## Lo que obtendrás  
- Aprenderás a diseñar y ejecutar estudios de fotoestabilidad conforme a la ICH Q1B sin poner en riesgo la integridad del producto.  
- Podrás reconocer los factores críticos que afectan los resultados y cómo controlarlos adecuadamente.  
- Observarás cómo mantener la trazabilidad y reproducibilidad en estos ensayos fortalece el proceso de registro y aprobación regulatoria.  
', 'https://i.ibb.co/jv6nHKzL/image.png', 'https://i.ibb.co/YBbLMgSJ/Mesa-de-trabajo-109-copia-3.png', NULL, 60, 21, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(36, '2025-09-03', '18:00-18:45', 'sala4', 'Certificación de Cabinas de Bioseguridad', 'certificacion-de-cabinas-de-bioseguridad', 'Diether Aguirre / Edwin Aparicio', 'Perú', 'Este taller se centrará en los ensayos requeridos para la certificación de cabinas de bioseguridad clase II, conforme a la norma NSF/ANSI 49:2024. Está dirigido a técnicos, usuarios y responsables de laboratorios de bioseguridad que buscan garantizar el cumplimiento de los parámetros normativos que aseguran una operación segura y eficaz.

### Contenido y dinámicas
Se abordarán los métodos de prueba establecidos por la norma para evaluar el desempeño de la cabina. Entre ellos destacan:

- Medición de velocidad de flujo de aire descendente y de ingreso.
- Prueba de integridad de filtros PAO.
- Ensayo de flujo de aire de la cabina (prueba de humo).
- Prueba de alarma y más.

Se realizarán demostraciones de cada ensayo, además, se revisarán criterios de aceptación e instrumentos utilizados.

### Lo que obtendrás
Al finalizar, estarás capacitado para interpretar correctamente los ensayos de certificación según NSF/ANSI 49:2024, entendiendo la importancia de mantener tu equipo certificado periódicamente para garantizar la seguridad requerida para la protección del operador, producto y el ambiente.
', 'https://i.ibb.co/v60bPqB4/escass.webp', 'https://i.ibb.co/9k2Sx9QX/Mesa-de-trabajo-118-1.png', 12, 60, 73, 1, '2025-06-05 13:12:07', '["Farmacéutica"]'),
(41, '2025-09-04', '15:00-15:45', 'sala1', 'Buenas Prácticas para Mediciones Electroquímicas', 'filtros', 'Samuel Francoi', 'Francia', 'Podrás descubrir cómo aplicar buenas prácticas en mediciones electroquímicas es fundamental para obtener resultados confiables, reproducibles y alineados con las exigencias normativas del laboratorio. Encontraremos en esta sesión cómo las soluciones de la marca HORIBA permiten optimizar desde la calibración y uso correcto de electrodos hasta la interpretación precisa de parámetros como pH, conductividad, ORP e iones específicos. Observaremos cómo pequeños errores en la preparación, mantenimiento o manipulación pueden comprometer significativamente la calidad de los datos obtenidos.

## Contenido y dinámicas prácticas  
- **Fundamentos de la medición electroquímica**: Principios de funcionamiento, condiciones de medición y factores que afectan la exactitud.  
- **Calibración y mantenimiento de electrodos**: Frecuencia recomendada, soluciones estándar y prevención de contaminación cruzada.  
- **Configuración adecuada del equipo HORIBA**: Selección del sensor, compensación automática de temperatura y registro digital de datos.  
- **Errores comunes y cómo evitarlos**: Mala inmersión del electrodo, electrodos secos o contaminados, y uso incorrecto de soluciones de calibración.

## Lo que obtendrás  
- Aprenderás a aplicar rutinas precisas de calibración y medición para asegurar resultados válidos y comparables.  
- Podrás aprovechar al máximo las funcionalidades de los equipos HORIBA en diferentes tipos de muestras y matrices.  
- Observarás cómo una medición electroquímica bien realizada se convierte en un pilar clave de control de calidad y análisis ambiental.  
', 'https://i.ibb.co/mrRR5Kfz/horibaa.png', 'https://i.ibb.co/kVQ1114G/Mesa-de-trabajo-128-copia.png', NULL, 60, 60, 1, '2025-06-05 13:12:07', '["Minería"]'),
(42, '2025-09-04', '15:00-15:45', 'sala2', 'Campanas sin estándares: Un riesgo silencioso en minería', 'campanas-sin-estandares-un-riesgo-silencioso-en-mineria', 'Fis. Wilmer Matta / Ing. Milagros Passaro', 'Perú', 'Podrás descubrir por qué el uso de campanas extractoras sin certificación representa un riesgo silencioso pero significativo en laboratorios mineros y de análisis químico. Encontraremos en esta sesión cómo la ausencia de estándares técnicos, validaciones y pruebas de contención puede comprometer no solo la calidad analítica, sino también la salud del personal y la integridad del entorno de trabajo. Observaremos cómo una campana mal diseñada o sin evaluación puede generar exposiciones a vapores tóxicos, contaminaciones cruzadas y fallos en auditorías regulatorias.

## Contenido y dinámicas prácticas  
- **Riesgos asociados a campanas no certificadas**: Fugas de contaminantes, falta de contención efectiva y exposición prolongada a vapores peligrosos.  
- **Normativas y estándares clave**: Importancia del cumplimiento con normas como ASHRAE 110, EN 14175 o ANSI Z9.5 en entornos de minería.  
- **Elementos críticos de diseño**: Velocidad de captura, tipo de ventilación, materiales resistentes y pruebas de desempeño.  
- **Buenas prácticas de evaluación y mantenimiento**: Protocolos de revisión periódica, monitoreo de funcionamiento y certificación de terceros.

## Lo que obtendrás  
- Aprenderás a identificar las características esenciales que debe cumplir una campana segura y eficiente.  
- Podrás evaluar el riesgo operativo de equipos sin validación técnica adecuada.  
- Observarás cómo una inversión en campanas certificadas mejora la protección del personal y fortalece el cumplimiento normativo en laboratorios de minería.  
', 'https://i.ibb.co/NdbBBfNb/esc-2.webp', 'https://i.ibb.co/TDhmdZwN/Mesa-de-trabajo-118-2.png', 3, 60, 36, 1, '2025-06-05 13:12:07', '["Minería"]'),
(43, '2025-09-04', '15:00-15:45', 'sala3', 'Lavado Automatizado y Vidrio Borosilicato para el laboratorio moderno sostenible.', 'lavado-automatizado-para-el-laboratorio-moderno', 'Ing. Manuel Mosqueira - Asesor Técnico ', 'Perú', 'Podrás descubrir cómo la automatización del lavado de vidriería, utensilios y herramientas de laboratorio —con la tecnología de la marca Miele— optimiza la eficiencia operativa y asegura altos estándares de limpieza, reproducibilidad y trazabilidad. Encontraremos en esta sesión cómo los sistemas de lavado automatizado reemplazan procesos manuales propensos a errores, reduciendo el riesgo de contaminación cruzada y mejorando la seguridad del personal. Observaremos cómo una limpieza controlada y documentada es clave en laboratorios modernos que manejan muestras sensibles o trabajan bajo normas reguladas.

## Contenido y dinámicas prácticas  
- **Tecnología Miele en lavado automatizado**: Diseño de ciclos validados, control de temperatura, uso eficiente de agua y detergente.  
- **Adaptabilidad a diferentes laboratorios**: Soluciones modulares para laboratorios clínicos, farmacéuticos, ambientales y de investigación.  
- **Rendimiento y trazabilidad**: Registro digital de ciclos, documentación automatizada y validación de limpieza.  
- **Sostenibilidad y eficiencia energética**: Equipos de bajo consumo, materiales durables y reducción de desechos químicos.

## Lo que obtendrás  
- Aprenderás a integrar un sistema de lavado automatizado que garantice limpieza validada y consistente.  
- Podrás mejorar el flujo de trabajo en el laboratorio reduciendo tiempos y errores asociados al lavado manual.  
- Observarás cómo la tecnología Miele combina eficacia, seguridad y sostenibilidad para cumplir con los más altos estándares de calidad.  
', 'https://i.ibb.co/nNDGJxQ0/mill.webp', 'https://i.ibb.co/d0wJtTzs/Mesa-de-trabajo-141-copia.png', NULL, 60, 26, 1, '2025-06-05 13:12:07', '["Minería"]'),
(44, '2025-09-04', '15:00-15:45', 'sala4', 'Importancia de sistema de digestión SNRG por rampas en análisis de metales', 'importancia-de-sistema-de-digestion-snrg-por-rampas-en-analisis-de-metales', 'Qco. James Rojas Sanchez - Asesor Técnico ', 'Perú', 'Podrás descubrir cómo el sistema de digestión por rampas SNRG, desarrollado por la marca Analytichem, representa una solución avanzada y precisa para la preparación de muestras en análisis de metales. Encontraremos en esta sesión cómo esta tecnología permite una digestión controlada por etapas, optimizando la descomposición de matrices orgánicas e inorgánicas sin pérdida de analitos. Observaremos cómo la precisión térmica y la reproducibilidad del sistema SNRG aseguran resultados confiables en técnicas posteriores como ICP-OES, ICP-MS o AAS.

## Contenido y dinámicas prácticas  
- **Principios del sistema SNRG**: Control de temperatura por rampas programables, distribución uniforme del calor y capacidad multireactor.  
- **Ventajas frente a métodos convencionales**: Reducción de tiempos, minimización de errores por sobrecalentamiento y mejor recuperación de metales traza.  
- **Aplicaciones típicas**: Preparación de muestras ambientales, alimentos, suelos, aguas y productos farmacéuticos.  
- **Compatibilidad con análisis instrumental**: Optimización para técnicas espectroscópicas y mejora de la calidad analítica.

## Lo que obtendrás  
- Aprenderás a utilizar sistemas de digestión por rampas para mejorar la precisión y eficiencia en el análisis de metales.  
- Podrás diseñar métodos de digestión más seguros y reproducibles con el respaldo tecnológico de Analytichem.  
- Observarás cómo esta tecnología contribuye a una preparación de muestras más estandarizada, controlada y orientada al cumplimiento normativo.  
', 'https://i.ibb.co/YFCB0W8H/sncrg-anals.webp', 'https://i.ibb.co/HD1m3sGV/Mesa-de-trabajo-141-2.png', 9, 60, 25, 1, '2025-06-05 13:12:07', '["Minería", "Farmacéutica"]'),
(45, '2025-09-04', '16:00-16:45', 'sala1', 'El rol de la calidad del agua en los ensayos analíticos', 'el-rol-de-la-calidad-del-agua-en-los-ensayos-analiticos', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Podrás comprender cómo la calidad del agua utilizada en laboratorios mineros influye directamente en la precisión y repetibilidad de los resultados analíticos. Encontraremos en esta jornada los requerimientos clave del agua para técnicas como espectroscopía, gravimetría y titulación aplicadas a minerales, metales y soluciones lixiviadas. Observaremos cómo una correcta selección y control del sistema de purificación permite evitar interferencias, garantizar la trazabilidad de los datos y optimizar la operación del laboratorio en el sector minero.

### Contenido y dinámicas prácticas  
- **Impacto de contaminantes en el análisis**: Cómo iones traza, materia orgánica o partículas afectan resultados.  
- **Calidad de agua según técnica analítica**: Requisitos para AAS, ICP, XRF y otros métodos comunes en minería.  
- **Soluciones para entornos exigentes**: Sistemas de purificación en zonas remotas o con agua de baja calidad.  

', 'https://i.ibb.co/d0SWrrDz/sart-puriif.webp', 'https://i.ibb.co/rfpNV5Rq/Mesa-de-trabajo-128-copia-2.png', 5, 70, 70, 1, '2025-06-05 13:12:07', '["Salud", "Educación", "Aguas y bebidas", "Alimentos", "Farmacéutica"]'),
(46, '2025-09-04', '16:00-16:45', 'sala2', 'Eficiencia y Sostenibilidad en Sistemas de Extracción de Gases', 'eficiencia-y-sostenibilidad-en-sistemas-de-extraccion-de-gases', 'Jhonny Quispe', 'Perú', '
Conoce la importancia de los sistemas de extracción de gases eficientes, sostenibles y seguros. Esta presentación resalta cómo el mantenimiento, la instalación adecuada y la certificación garantizan un entorno seguro y conforme a las normativas, previniendo riesgos operativos y contribuyendo a la sostenibilidad y responsabilidad ambiental.

### Contenido y dinámicas prácticas
- Introducción a campanas extractoras y scrubbers: tipos, funciones y su importancia en bioseguridad.
- Componentes clave de un sistema de extracción: campana, ductos, extractor y lavador de gases (scrubber).
- Personalización de scrubbers: diseño y fabricación adaptada a necesidades específicas.
- Buenas prácticas y eficiencia energética: ahorro energético, cumplimiento normativo y responsabilidad ambiental.
- Importancia del mantenimiento preventivo y la certificación: prevención de riesgos operativos y cumplimiento legal.

### Lo que obtendrás
- Identificarás componentes críticos y buenas prácticas para una operación segura y eficiente.
- Conocerás cómo la certificación y el mantenimiento preventivo evitan riesgos operativos y ambientales.
- Observarás casos reales que demuestran los beneficios de un mantenimiento especializado.
- Aprenderás cómo KOSSOMET puede apoyarte con soluciones personalizadas y certificadas.
', 'https://i.ibb.co/pjzC7Fxd/ddssdc.webp', 'https://i.ibb.co/4nSN5NPQ/Mesa-de-trabajo-132-1.png', 12, 60, 18, 1, '2025-06-05 13:12:07', '["Minería"]'),
(47, '2025-09-04', '16:00-16:45', 'sala3', 'Tratamiento y determinación de hidrocarburos de petróleo por cromatografía de gases.', 'tratamiento-y-determinacion-de-hidrocarburos-de-petroleo-por-cromatografia-de-gases', 'Qco. James Rojas Sanchez - Asesor Técnico ', 'Perú', 'Podrás descubrir cómo la cromatografía de gases (GC) es una de las herramientas más confiables y precisas para el tratamiento y determinación de hidrocarburos de petróleo en matrices como suelos, aguas, sedimentos y residuos industriales. Encontraremos en esta sesión cómo utilizar esta técnica para separar, identificar y cuantificar compuestos como los hidrocarburos alifáticos y aromáticos, clave en estudios de impacto ambiental, control de derrames y monitoreos normativos. Observaremos cómo un análisis cromatográfico bien diseñado permite cumplir con metodologías como EPA 8015, asegurando resultados robustos y trazables.

## Contenido y dinámicas prácticas  
- **Fundamentos de GC en análisis de hidrocarburos**: Principio de separación, detección por ionización de llama (FID) y parámetros críticos para obtener resultados confiables.  
- **Preparación de muestras**: Extracción, limpieza, concentración y manejo seguro de matrices ambientales y contaminadas.  
- **Rangos de análisis**: Evaluación de TPH (Total Petroleum Hydrocarbons), fracciones DRO (Diesel Range Organics) y GRO (Gasoline Range Organics).  
- **Cumplimiento normativo**: Aplicación de metodologías estandarizadas como EPA 8015 y criterios de validación para informes ambientales.

## Lo que obtendrás  
- Aprenderás cómo implementar análisis de hidrocarburos con cromatografía de gases de forma efectiva y reproducible.  
- Podrás aplicar buenas prácticas para la preparación de muestras y configuración del equipo GC según el tipo de hidrocarburo.  
- Observarás cómo esta técnica mejora la precisión del diagnóstico ambiental y el cumplimiento con regulaciones nacionales e internacionales.  
', 'https://i.ibb.co/1fdcp21B/young-in.jpg', 'https://i.ibb.co/8nQ49WV5/Mesa-de-trabajo-141.png', NULL, 60, 55, 1, '2025-06-05 13:12:07', '["Química & Petrolera"]'),
(48, '2025-09-04', '16:00-16:45', 'sala4', 'Calibración de medidores volumétricos (Lab Gdes. Volúmenes)', 'calibracion-de-medidores-volumetricos-lab-gdes-volumenes-2', 'Lic. Luis E. Urbano', 'Perú', 'En esta charla se podrá conocer la forma de calibración de medidores volumétricos metálicos de diferentes clases y por diferentes métodos, tales como el método gravimétrico y el método volumétrico.  
Conoceremos los fundamentos técnicos de calibración de ambos métodos usando patrones trazables al SI (Sistema Internacional de Unidades).  
Podrás conocer de forma teórica y práctica la calibración de medidores de grandes volúmenes, usados en diferentes industrias.

### Contenido y dinámicas prácticas
- **Principios de calibración**: Revisión de fundamentos técnicos y normativos tales como la ISO, Guías y Norma Metrológica Peruana.  
- **Técnicas de calibración directa e indirecta**: Calibración por método volumétrico y calibración por método gravimétrico. Ventajas del uso de cada método.  
- **Instrumentos y condiciones críticas**: Medidores volumétricos patrones, instrumentos para medir la temperatura del medio ambiente y del líquido, y los requisitos que se necesitan para realizar la calibración de ambos métodos.  
- **Ejercicios prácticos**: Ensayo práctico de cómo se calibra un serafín de 5 galones por el método volumétrico (con enfoque didáctico).  

### Lo que obtendrás
- Podrás aplicar procedimientos de calibración adecuados según el tipo de medidor y rango de volumen.  
- Aprenderás a identificar fuentes de error y cómo minimizarlas en tus mediciones diarias.  
- Observaremos casos reales y soluciones aplicadas para mantener la precisión de equipos en laboratorios, industria o investigación.


', 'https://i.ibb.co/VcspRpwY/kssdd.webp', 'https://i.ibb.co/4wmpm0V1/Mesa-de-trabajo-82-1.png', 12, 60, 60, 1, '2025-06-05 13:12:07', '["Minería"]'),
(49, '2025-09-04', '17:00-17:45', 'sala1', 'Innovación en Pesaje de Laboratorio: Sustentabilidad e Integridad de Datos.', 'balanzas-de-laboratorio-con-conciencia-ecologica-2', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Descubre cómo las nuevas generaciones de balanzas de laboratorio no solo mejoran la precisión del pesaje, sino que también contribuyen a una operación más sostenible, eficiente y trazable. Esta sesión te permitirá conocer cómo integrar criterios ecológicos en tu flujo de trabajo sin comprometer el rendimiento analítico.

## Lo que podrás observar  
- Características de diseño que reducen el consumo energético y la huella ecológica.  
- Funcionalidades que facilitan un manejo intuitivo, reduciendo errores humanos y tiempos de entrenamiento.  
- Integración con sistemas digitales para garantizar trazabilidad, cumplimiento normativo y protección de datos.  

## ¿Por qué es relevante?  
Porque en un laboratorio moderno, eficiencia y sostenibilidad deben ir de la mano. Esta charla te dará una visión clara sobre cómo elegir el equipo adecuado para cumplir con tus objetivos operativos, regulatorios y ambientales.
', 'https://i.ibb.co/0ycwBYn8/balanza-232-2.webp', 'https://i.ibb.co/hJSH5P7h/Mesa-de-trabajo-128.png', 5, 60, 36, 1, '2025-06-05 13:12:07', '["Minería", "Salud", "Química & Petrolera", "Educación", "Aguas y bebidas", "Farmacéutica", "Alimentos", "Pesquera"]'),
(50, '2025-09-04', '17:00-17:45', 'sala2', 'Vacío que cumple: Tecnología inteligente para auditar sin estrés', 'vacio-que-cumple-tecnologia-inteligente-para-auditar-sin-estres-2', 'Dr. Roberto Friztler', 'Alemania', 'Podrás descubrir cómo los sistemas de vacío modernos, diseñados con tecnología inteligente, pueden convertirse en aliados estratégicos para superar auditorías sin estrés y con trazabilidad garantizada. Encontraremos en esta sesión cómo integrar bombas y sistemas de vacío con control digital, monitoreo en tiempo real y validación documental permite minimizar errores, cumplir normativas exigentes y asegurar condiciones reproducibles. Observaremos cómo esta tecnología es especialmente útil en laboratorios regulados y áreas donde la integridad del proceso es crítica.

## Contenido y dinámicas prácticas  
- **Tecnología inteligente aplicada al vacío**: Control de parámetros, programación de rampas, interfaces digitales y conectividad para trazabilidad.  
- **Ventajas frente a sistemas convencionales**: Mayor estabilidad de presión, menor mantenimiento y validación más sencilla.  
- **Cumplimiento normativo y auditorías**: Cómo los sistemas de vacío validables ayudan a cumplir con GMP, ISO y auditorías regulatorias.  
- **Aplicaciones críticas**: Filtraciones sensibles, evaporación, secado, procesos de concentración y soporte en líneas de producción o investigación.

## Lo que obtendrás  
- Aprenderás a identificar las características clave de un sistema de vacío listo para auditorías exigentes.  
- Podrás reducir riesgos de desviaciones técnicas mediante control preciso y documentación automatizada.  
- Observarás cómo implementar esta tecnología mejora la eficiencia, la seguridad y la confianza en entornos regulados.  
', 'https://i.postimg.cc/76ZxtKsW-/enhanced-image-5.png', 'https://i.ibb.co/b5RzQdqs/Mesa-de-trabajo-102-2.png', 4, 60, 9, 1, '2025-06-05 13:12:07', '["Minería"]'),
(51, '2025-09-04', '17:00-17:45', 'sala3', 'Pulverizadoras Vs. Contaminación Cruzada', 'pulverizadoras-vs-contaminacion-cruzada', 'Ing. Manuel Mosqueira - Asesor Técnico ', 'Perú', 'Podrás descubrir cómo el diseño inteligente de las pulverizadoras de la marca Fritsch permite minimizar de forma efectiva el riesgo de contaminación cruzada en la preparación de muestras. Encontraremos en esta sesión cómo la elección del tipo de molino, los materiales de construcción y los protocolos de limpieza influyen directamente en la pureza y reproducibilidad del análisis, especialmente en laboratorios de alimentos, minería, medio ambiente y farmacéutica. Observaremos cómo una preparación adecuada de muestra es tan crítica como la etapa analítica, y cómo prevenir interferencias desde el primer paso.

## Contenido y dinámicas prácticas  
- **Diseño Fritsch para evitar contaminaciones**: Cámaras de molienda intercambiables, materiales resistentes (como acero inoxidable, carburo de tungsteno o cerámica) y limpieza simplificada.  
- **Comparativa de tecnologías de pulverización**: Molinos de bolas, de rotor, de cuchillas y de discos —selección según tipo de muestra y nivel de riesgo.  
- **Buenas prácticas para prevenir contaminación**: Protocolos de limpieza, uso de sets dedicados por matriz y validación de blancos.  
- **Casos de aplicación reales**: Laboratorios donde la prevención de contaminación cruzada ha mejorado significativamente la calidad del resultado.

## Lo que obtendrás  
- Aprenderás a seleccionar el sistema de pulverización más adecuado para tu muestra y tipo de análisis.  
- Podrás reducir el riesgo de resultados falsos o interferencias causadas por residuos de muestras anteriores.  
- Observarás cómo las soluciones Fritsch permiten mayor control, trazabilidad y calidad desde el inicio del proceso analítico.  
', 'https://www.fritsch-international.com/fileadmin/_processed_/csm_Sample-preparation-min_6af34cd8da.png', 'https://i.ibb.co/5XPPPsG7/Mesa-de-trabajo-141-1.png', NULL, 60, 26, 1, '2025-06-05 13:12:07', '["Minería"]'),
(52, '2025-09-04', '17:00-17:45', 'sala4', 'Certificación de Campanas Extractoras ', 'certificacion-de-campanas-extractoras-lab-de-uia', 'Diether Aguirre / Edwin Aparicio', 'Perú', '
Este taller está orientado a la ejecución e interpretación de los ensayos de desempeño requeridos para la certificación de campanas extractoras de laboratorio, conforme a la norma ANSI/ASHRAE 110:2016. El enfoque está en validar su capacidad de contención de contaminantes y estabilidad del flujo de aire.

### Contenido y dinámicas
- Se explicarán los ensayos principales de la norma: la visualización del patrón de flujo con un generador de humo y la medición de velocidad de ingreso de aire.  
- Se analizarán los criterios de aceptación para cada prueba, los equipos requeridos, la preparación del entorno y la interpretación de resultados.  
- Se realizarán ejercicios prácticos para demostrar el proceso.

### Lo que obtendrás
- Al finalizar, estarás en capacidad de evaluar correctamente los ensayos de certificación bajo ASHRAE 110:2016.  
- Asegurarás que la campana extractora proporcione una protección efectiva al usuario.  
- Cumplirás con los estándares de seguridad química en el laboratorio.


', 'https://i.ibb.co/v60bPqB4/escass.webp', 'https://i.ibb.co/TBk64HZY/Mesa-de-trabajo-118-3.png', 12, 60, 60, 1, '2025-06-05 13:12:07', '["Minería"]'),
(53, '2025-09-04', '18:00-18:45', 'sala1', 'Integridad de datos en la rutina diaria de pesaje en el laboratorio', 'integridad-de-datos-en-la-rutina-diaria-de-pesaje-en-el-laboratorio', 'Lic. Mónica Klarreich & Cesar Montes de Oca', 'Argentina', 'Descubre cómo asegurar la integridad de datos en el pesaje diario es clave para lograr trazabilidad, confiabilidad y cumplimiento regulatorio en laboratorios modernos. En esta sesión conocerás cómo la tecnología de Sartorius permite capturar, gestionar y proteger cada dato generado durante el pesaje, desde la lectura inicial hasta su almacenamiento final sin necesidad de intervención manual. Analizaremos cómo la automatización, la conectividad y el cumplimiento de normativas como ALCOA+ ayudan a prevenir errores, manipulaciones y pérdidas de información crítica.

### Contenido y dinámicas prácticas  
- **Principios de integridad de datos (ALCOA+)**: Qué significa que un dato sea atribuible, legible, contemporáneo, original y exacto, y cómo aplicarlo al pesaje.  
- **Soluciones Sartorius para gestión segura de datos**: Balanzas con interfaces digitales, generación automática de reportes, conectividad con software LIMS y firma electrónica.  
- **Cumplimiento normativo y auditorías**: Requisitos de regulaciones como GMP, FDA 21 CFR Part 11 e ISO 17025 en relación al manejo de datos.  

### Lo que obtendrás  
- Aprenderás a integrar prácticas y herramientas que aseguren la integridad de los datos de pesaje en cada etapa del proceso.  
- Podrás automatizar la documentación del pesaje para reducir errores humanos y fortalecer el cumplimiento regulatorio.  
- Verás cómo las soluciones Sartorius transforman el pesaje en un proceso más confiable, auditado y libre de riesgo.  

', 'https://i.ibb.co/PsxnXTJ9/microbalanza-2.webp', 'https://i.ibb.co/0gZW1Lc/Mesa-de-trabajo-128-1.png', 5, 60, 60, 1, '2025-06-05 13:12:07', '["Minería", "Farmacéutica"]'),
(54, '2025-09-04', '18:00-18:45', 'sala2', 'Introducción a la geometalurgia', 'no-hay', 'Ing. José Andrés Yparraguirre', 'Perú', 'Podrás descubrir cómo la geometalurgia se ha convertido en una herramienta clave para optimizar la toma de decisiones en proyectos mineros, integrando información geológica, mineralógica y metalúrgica desde etapas tempranas de exploración hasta la operación. Encontraremos en esta sesión cómo las soluciones de caracterización avanzada de la marca Evident —especialmente en microscopía y análisis de imágenes— permiten entender la distribución, textura y comportamiento de los minerales de interés. Observaremos cómo esta visión integral permite reducir riesgos, mejorar la recuperación y maximizar el valor del recurso.

## Contenido y dinámicas prácticas  
- **Fundamentos de la geometalurgia**: Integración de datos mineralógicos, químicos y metalúrgicos para modelar el comportamiento del mineral.  
- **Caracterización mineralógica con Evident**: Uso de microscopía óptica y digital para analizar textura, asociación y liberación mineral.  
- **Aplicación en el ciclo minero**: Apoyo en planificación de mina, diseño de procesos, control de calidad y predicción de desempeño metalúrgico.  
- **Ventajas estratégicas**: Mejora en eficiencia operativa, reducción de costos por reprocesamiento y toma de decisiones basada en datos integrados.

## Lo que obtendrás  
- Aprenderás a aplicar principios básicos de geometalurgia apoyándote en herramientas de caracterización de última generación.  
- Podrás interpretar datos mineralógicos con enfoque en procesos y recuperación.  
- Observarás cómo la geometalurgia fortalece la planificación técnica y económica en proyectos mineros complejos.  
', 'https://i.ibb.co/SXN95hGZ/enhanced-image-6.png', 'https://i.ibb.co/mLz6RDC/Mesa-de-trabajo-102-copia.png', NULL, 60, 94, 1, '2025-06-05 13:12:07', '["Minería", "Química & Petrolera"]'),
(55, '2025-09-04', '18:00-18:45', 'sala3', 'Secado al vacío en minería: Más seco, más rentable', 'secado-al-vacio-en-mineria-mas-seco-mas-rentable', 'Guillermo Casanovas y Roberto Friztler', 'Argentina', 'Podrás descubrir cómo la combinación de tecnologías de vacío y control térmico, de marcas como Vacuubrand y Binder, ofrece una solución integral para el secado eficiente de concentrados minerales y otras muestras en el sector minero. Encontraremos en esta sesión cómo el secado al vacío no solo acelera el proceso y mejora la estabilidad del producto, sino que también reduce el consumo energético, el riesgo de oxidación y las pérdidas económicas por humedad residual. Observaremos cómo un secado controlado, reproducible y documentado puede marcar la diferencia en calidad, seguridad y rentabilidad.

## Contenido y dinámicas prácticas  
- **Principios del secado al vacío**: Eliminación de humedad a baja temperatura y presión reducida, ideal para compuestos sensibles o con alto valor económico.  
- **Ventajas técnicas y económicas**: Menor tiempo de secado, mayor recuperación de material, transporte más eficiente y reducción de rechazos.  
- **Soluciones Vacuubrand + Binder**: Integración de bombas de vacío inteligentes y estufas con control térmico preciso y validación digital.  
- **Aplicaciones en minería**: Secado de concentrados de cobre, zinc, oro, litio y otros metales estratégicos, en laboratorios y plantas piloto.

## Lo que obtendrás  
- Aprenderás cómo implementar un sistema de secado al vacío eficiente y adaptado a las exigencias del sector minero.  
- Podrás reducir tiempos, costos operativos y riesgos en el manejo de concentrados húmedos.  
- Observarás cómo las soluciones combinadas de Vacuubrand y Binder elevan la calidad del proceso y aumentan la rentabilidad de tu operación.  

', 'https://i.ibb.co/vvvFk93k/vaccdd.webp', 'https://i.ibb.co/CKzWCBWw/Mesa-de-trabajo-141-copia-2.png', 7, 60, 28, 1, '2025-06-05 13:12:07', '["Minería"]'),
(56, '2025-09-04', '18:00-18:45', 'sala4', 'Análisis Ambiental discreto automatizado de los vertidos mineros', 'analisis-ambiental-discreto-automatizado-de-los-vertidos-mineros', 'Qco. James Rojas Sanchez', 'Perú', 'Podrás descubrir cómo el análisis ambiental discreto automatizado se ha convertido en una solución clave para optimizar el monitoreo de vertidos mineros, permitiendo una evaluación precisa, eficiente y sostenible de múltiples parámetros de interés. Encontraremos en esta sesión cómo esta tecnología mejora significativamente la productividad en laboratorios que deben analizar grandes volúmenes de muestras, asegurando resultados consistentes, trazables y alineados con las normativas ambientales. Observaremos cómo esta metodología reduce errores operativos y tiempos de respuesta, facilitando decisiones rápidas en gestión de residuos.

## Contenido y dinámicas prácticas  
- **Principios del análisis discreto automatizado**: Sistemas por cubeta individual, control de reactivos y medición secuencial para múltiples parámetros.  
- **Parámetros críticos en residuos de mina**: Nitratos, sulfatos, fosfatos, metales pesados y DQO, entre otros.  
- **Ventajas operativas**: Alta capacidad de análisis, reducción en el consumo de reactivos, mínima intervención humana y trazabilidad digital.  
- **Aplicación en entornos mineros**: Casos reales de implementación, cumplimiento con regulaciones y mejora en tiempos de reporte.

## Lo que obtendrás  
- Aprenderás cómo automatizar el análisis ambiental de vertidos mineros sin comprometer precisión ni cumplimiento normativo.  
- Podrás manejar grandes volúmenes de muestras con mayor eficiencia y menor riesgo de error.  
- Observarás cómo esta tecnología fortalece la estrategia de monitoreo ambiental y gestión de residuos en operaciones mineras.  
', 'https://i.ibb.co/vvwx7NGC/enhanced-image-4.png', 'https://i.ibb.co/m5v7Rwsx/Mesa-de-trabajo-88-2.png', 10, 60, 39, 1, '2025-06-05 13:12:07', '["Minería"]');

