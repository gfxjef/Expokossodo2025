-- Estructura de tabla expokossodo_registros
-- Fecha: 2025-09-02 09:01:26.217257
-- Registros: 1047

DROP TABLE IF EXISTS expokossodo_registros_backup;
CREATE TABLE `expokossodo_registros_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombres` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `empresa` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cargo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expectativas` text COLLATE utf8mb4_unicode_ci,
  `eventos_seleccionados` json DEFAULT NULL,
  `qr_code` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_generado_at` timestamp NULL DEFAULT NULL,
  `asistencia_general_confirmada` tinyint(1) DEFAULT '0',
  `fecha_asistencia_general` timestamp NULL DEFAULT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `confirmado` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=1123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

