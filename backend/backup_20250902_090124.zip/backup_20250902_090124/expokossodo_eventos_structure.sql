-- Estructura de tabla expokossodo_eventos
-- Fecha: 2025-09-02 09:01:27.573255
-- Registros: 48

DROP TABLE IF EXISTS expokossodo_eventos_backup;
CREATE TABLE `expokossodo_eventos_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sala` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo_charla` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expositor` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `imagen_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca_id` int DEFAULT NULL,
  `slots_disponibles` int DEFAULT '60',
  `slots_ocupados` int DEFAULT '0',
  `disponible` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `rubro` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_fecha_hora` (`fecha`,`hora`),
  KEY `idx_sala` (`sala`),
  KEY `idx_slug` (`slug`),
  KEY `fk_evento_marca` (`marca_id`),
  KEY `idx_rubro` ((cast(`rubro` as char(100) charset utf8mb4))),
  CONSTRAINT `fk_evento_marca` FOREIGN KEY (`marca_id`) REFERENCES `expokossodo_marcas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

