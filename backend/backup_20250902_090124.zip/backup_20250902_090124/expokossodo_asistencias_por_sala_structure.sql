-- Estructura de tabla expokossodo_asistencias_por_sala
-- Fecha: 2025-09-02 09:01:28.296249
-- Registros: 9

DROP TABLE IF EXISTS expokossodo_asistencias_por_sala_backup;
CREATE TABLE `expokossodo_asistencias_por_sala_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `registro_id` int NOT NULL,
  `evento_id` int NOT NULL,
  `qr_escaneado` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_ingreso` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `asesor_verificador` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_verificacion` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notas` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_registro_evento_ingreso` (`registro_id`,`evento_id`),
  KEY `idx_evento_fecha` (`evento_id`,`fecha_ingreso`),
  KEY `idx_qr_escaneado` (`qr_escaneado`),
  CONSTRAINT `expokossodo_asistencias_por_sala_backup_ibfk_1` FOREIGN KEY (`registro_id`) REFERENCES `expokossodo_registros` (`id`) ON DELETE CASCADE,
  CONSTRAINT `expokossodo_asistencias_por_sala_backup_ibfk_2` FOREIGN KEY (`evento_id`) REFERENCES `expokossodo_eventos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

