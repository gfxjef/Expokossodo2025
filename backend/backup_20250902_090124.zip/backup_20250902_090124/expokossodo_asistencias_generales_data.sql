-- Datos de tabla expokossodo_asistencias_generales
-- Fecha: 2025-09-02 09:01:27.947250
-- Registros: 4

INSERT INTO expokossodo_asistencias_generales_backup (`id`, `registro_id`, `qr_escaneado`, `fecha_escaneo`, `verificado_por`, `ip_verificacion`) VALUES
(40, 865, 'jor51979603737docunp1756243305', '2025-09-01 16:05:59', 'Staff-Recepción', '127.0.0.1'),
(41, 1110, 'jor51968255746dirims1756749904', '2025-09-01 16:06:51', 'Staff-Recepción', '127.0.0.1'),
(42, 932, 'ric51990360028gersim1756317144', '2025-09-01 16:14:01', 'Staff-Recepción', '127.0.0.1'),
(43, 1114, 'jac960941218jefins1756756623', '2025-09-01 17:17:17', 'Staff-Recepción', '127.0.0.1');

