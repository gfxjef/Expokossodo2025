-- Estructura de tabla fb_leads
-- Fecha: 2025-09-02 09:01:31.226236
-- Registros: 733

DROP TABLE IF EXISTS fb_leads_backup;
CREATE TABLE `fb_leads_backup` (
  `id` bigint NOT NULL,
  `sala` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adset_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `raw_json` json NOT NULL,
  `ingested_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `form_id` bigint NOT NULL,
  `page_id` bigint NOT NULL,
  `campaign_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adset_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enviado` tinyint(1) DEFAULT '0',
  `procesado` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_campaign_name` (`campaign_name`),
  KEY `idx_adset_name` (`adset_name`),
  KEY `idx_ad_name` (`ad_name`),
  KEY `idx_sala` (`sala`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

