-- Estructura de tabla expokossodo_registro_eventos
-- Fecha: 2025-09-02 09:01:26.936253
-- Registros: 2327

DROP TABLE IF EXISTS expokossodo_registro_eventos_backup;
CREATE TABLE `expokossodo_registro_eventos_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `registro_id` int NOT NULL,
  `evento_id` int NOT NULL,
  `fecha_seleccion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_registro_evento` (`registro_id`,`evento_id`),
  KEY `evento_id` (`evento_id`),
  CONSTRAINT `expokossodo_registro_eventos_backup_ibfk_1` FOREIGN KEY (`registro_id`) REFERENCES `expokossodo_registros` (`id`) ON DELETE CASCADE,
  CONSTRAINT `expokossodo_registro_eventos_backup_ibfk_2` FOREIGN KEY (`evento_id`) REFERENCES `expokossodo_eventos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2504 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

