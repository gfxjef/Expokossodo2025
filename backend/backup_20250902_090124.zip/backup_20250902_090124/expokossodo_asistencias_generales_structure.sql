-- Estructura de tabla expokossodo_asistencias_generales
-- Fecha: 2025-09-02 09:01:27.945250
-- Registros: 4

DROP TABLE IF EXISTS expokossodo_asistencias_generales_backup;
CREATE TABLE `expokossodo_asistencias_generales_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `registro_id` int NOT NULL,
  `qr_escaneado` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_escaneo` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `verificado_por` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Sistema',
  `ip_verificacion` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_registro_fecha` (`registro_id`,`fecha_escaneo`),
  KEY `idx_qr_escaneado` (`qr_escaneado`),
  CONSTRAINT `expokossodo_asistencias_generales_backup_ibfk_1` FOREIGN KEY (`registro_id`) REFERENCES `expokossodo_registros` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

